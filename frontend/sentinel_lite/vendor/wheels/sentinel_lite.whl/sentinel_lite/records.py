from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass(frozen=True)
class InventoryRow:
    sort_key: str
    section: str
    template: str
    place: str = ""
    object: str = ""
    pane: str = ""
    item: str = ""
    device: str = ""
    source: str = ""
    page: str = ""
    layer: str = ""
    viewport: str = ""
    viewport_layer: str = ""
    type: str = ""
    identity: str = ""
    macro_scope: str = ""
    variable_scope: str = ""
    page_link: str = ""
    change: str = "inventory"
    details: str = ""
    source_table: str = ""
    source_key: str = ""
    unresolved: str = ""
    identity_key: str = ""
    extras: dict[str, str] = field(default_factory=dict)

    def as_csv_dict(self) -> dict[str, str]:
        payload = asdict(self)
        payload.pop("extras")
        return {key: "" if value is None else str(value) for key, value in payload.items()}
