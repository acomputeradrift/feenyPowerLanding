from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path


# 64 MiB. The default 2 MB holds ~125 pages of a 16 KB-page .apex, which thrashes
# on the full-table scans in extract/programming.py and resolve/catalog.py.
PAGE_CACHE_KIB = 65536


@contextmanager
def open_apex(apex_path: Path) -> Iterator[sqlite3.Connection]:
    # as_uri() encodes spaces/parentheses. immutable=1 is required for WAL-mode
    # .apex copies opened read-only (no -wal/-shm beside the upload).
    uri = f"{Path(apex_path).resolve().as_uri()}?mode=ro&immutable=1"
    connection = sqlite3.connect(uri, uri=True)
    connection.execute(f"pragma cache_size = -{PAGE_CACHE_KIB}")
    connection.row_factory = sqlite3.Row
    connection.text_factory = lambda value: value.decode("utf-8", "replace") if isinstance(value, bytes) else value
    try:
        yield connection
    finally:
        connection.close()


def table_exists(connection: sqlite3.Connection, table_name: str) -> bool:
    row = connection.execute(
        "select 1 from sqlite_master where type in ('table', 'view') and name = ?",
        (table_name,),
    ).fetchone()
    return row is not None


def table_columns(connection: sqlite3.Connection, table_name: str) -> set[str]:
    return {str(row[1]) for row in connection.execute(f"pragma table_info({table_name})")}
