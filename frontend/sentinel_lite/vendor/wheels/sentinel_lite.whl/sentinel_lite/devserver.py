"""Localhost static server for developing the browser app.

Static files only. There is deliberately no compare, export, or upload
endpoint: `.apex` bytes never cross a network boundary, including localhost.
Compare runs in `web/worker.js` under Pyodide, and this server exists only
because a Worker and a `.wasm` module cannot be loaded from `file://`.

    python -m sentinel_lite serve --port 8766
"""

from __future__ import annotations

import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
_LOCAL_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})

CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".wasm": "application/wasm",
    ".whl": "application/zip",
    ".zip": "application/zip",
    ".woff2": "font/woff2",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
}


def default_web_root() -> Path:
    here = Path(__file__).resolve()
    repo_web = here.parents[2] / "web"
    if repo_web.is_dir():
        return repo_web
    return here.parent / "web"


def content_type(suffix: str) -> str:
    return CONTENT_TYPES.get(suffix.lower(), "application/octet-stream")


class DevserverHandler(BaseHTTPRequestHandler):
    web_root: Path = Path()

    def do_GET(self) -> None:
        self._serve_static(urlparse(self.path).path)

    def log_message(self, format: str, *args: object) -> None:
        sys.stderr.write("%s - %s\n" % (self.address_string(), format % args))

    def _serve_static(self, request_path: str) -> None:
        relative = unquote(request_path).lstrip("/")
        if not relative or relative.endswith("/"):
            relative = f"{relative}index.html"
        root = self.web_root.resolve()
        target = (root / relative).resolve()
        if root not in target.parents and target != root:
            self.send_error(404)
            return
        if not target.is_file():
            self.send_error(404)
            return
        data = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type(target.suffix))
        self.send_header("Content-Length", str(len(data)))
        # Dev only: production caches the vendored runtime immutably instead.
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)


def make_handler(web_root: Path) -> type[DevserverHandler]:
    class BoundHandler(DevserverHandler):
        pass

    BoundHandler.web_root = web_root
    return BoundHandler


def serve(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    web_root: Path | None = None,
) -> None:
    if host not in _LOCAL_HOSTS:
        raise ValueError("Dev server binds localhost only")
    root = (web_root or default_web_root()).resolve()
    server = ThreadingHTTPServer((host, port), make_handler(root))
    print(f"Open http://{host}:{server.server_port}", flush=True)
    server.serve_forever()
