"""I/O adapter for the in-browser worker.

Paths in, serialized bytes out, and nothing else. `.apex` files reach this module
as WORKERFS paths, so the bytes stay on the dealer's machine and never cross a
network boundary.

Both entry points return JSON text or bytes rather than Python objects — one
`json.dumps` plus one `JSON.parse` beats a `PyProxy` per changelog row.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path

from sentinel_lite import __version__
from sentinel_lite.export.write_changelog_xlsx import (
    meta_from_payload,
    write_changelog_xlsx_bytes,
)
from sentinel_lite.payload import result_payload
from sentinel_lite.pipeline import compare_apex_files

__all__ = ["__version__", "changelog_xlsx_bytes", "compare_to_json"]


def compare_to_json(
    previous_path: str,
    current_path: str,
    *,
    previous_name: str,
    current_name: str,
    on_progress: Callable[[str], None] | None = None,
) -> str:
    """Diff two mounted `.apex` files; return the `result` event as JSON text.

    The worker mounts files as `a.apex` / `b.apex` because client filenames
    contain spaces and parentheses that break SQLite URIs. The real names
    travel separately and are restored on the result.
    """
    result = compare_apex_files(
        Path(previous_path),
        Path(current_path),
        previous_file=_apex_label(previous_name, Path(previous_path).name),
        current_file=_apex_label(current_name, Path(current_path).name),
        on_progress=on_progress,
    )
    return json.dumps(result_payload(result), ensure_ascii=False)


def changelog_xlsx_bytes(payload_json: str) -> bytes:
    """Render the filtered changelog rows the UI is showing to xlsx bytes."""
    payload = json.loads(payload_json)
    if not isinstance(payload, dict):
        raise ValueError("payload object")
    entries = payload.get("entries")
    if not isinstance(entries, list):
        raise ValueError("entries")
    return write_changelog_xlsx_bytes(entries, meta_from_payload(payload))


def _apex_label(name: str, fallback: str) -> str:
    label = Path(str(name or "")).name.strip() or fallback
    return label if label.lower().endswith(".apex") else f"{label}.apex"
