from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from sentinel_lite.compare import compare_inventories
from sentinel_lite.compare.models import CompareResult
from sentinel_lite.inventory.collect import load_inventory_bundle

Progress = Callable[[str], None]


def compare_apex_files(
    previous_path: Path,
    current_path: Path,
    *,
    previous_file: str | None = None,
    current_file: str | None = None,
    on_progress: Progress | None = None,
) -> CompareResult:
    def note(text: str) -> None:
        if on_progress is not None:
            on_progress(text)

    def phase(label: str) -> Progress:
        # A browser run is long enough that three messages read as a hang.
        return lambda step: note(f"{label} — {step}…")

    note("Extracting A…")
    previous, previous_catalog = load_inventory_bundle(
        previous_path, on_progress=phase("Extracting A")
    )
    note("Extracting B…")
    current, current_catalog = load_inventory_bundle(
        current_path, on_progress=phase("Extracting B")
    )
    note("Diffing…")
    return compare_inventories(
        previous,
        current,
        previous_file=previous_file or previous_path.name,
        current_file=current_file or current_path.name,
        previous_catalog=previous_catalog,
        current_catalog=current_catalog,
    )
