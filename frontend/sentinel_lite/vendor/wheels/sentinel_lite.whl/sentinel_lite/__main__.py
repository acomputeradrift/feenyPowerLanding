from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from sentinel_lite.compare.write_csv import write_changelog_csv
from sentinel_lite.inventory.collect import load_inventory
from sentinel_lite.inventory.write_workbook import write_inventory_workbook
from sentinel_lite.pipeline import compare_apex_files
from sentinel_lite.devserver import DEFAULT_HOST, DEFAULT_PORT, serve

DEFAULT_APEX = Path(
    "/Users/jamiefeeny/Development (Not Shared)/Sentinel/Assets/1790 High Rd (Simple v28).apex"
)
DEFAULT_INVENTORY = Path("generated/1790_high_rd_simple_v28_inventory.xlsx")
DEFAULT_CHANGELOG = Path("generated/changelog.csv")

NO_CHANGES = "No changes since last file."
COMPARE_FAILED = "Changelog could not be computed."
COMMANDS = {"inventory", "compare", "serve", "-h", "--help"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Local two-file Apex changelog: inventory snapshot or compare."
    )
    sub = parser.add_subparsers(dest="command")

    inventory = sub.add_parser("inventory", help="Write a System + Programming inventory workbook")
    inventory.add_argument("--apex", type=Path, default=DEFAULT_APEX, help="Path to a local .apex file")
    inventory.add_argument("--out", type=Path, default=DEFAULT_INVENTORY, help="xlsx output path")

    compare = sub.add_parser("compare", help="Diff two .apex files and write changelog CSV")
    compare.add_argument("--a", type=Path, required=True, help="Previous .apex file")
    compare.add_argument("--b", type=Path, required=True, help="Current .apex file")
    compare.add_argument("--out", type=Path, default=DEFAULT_CHANGELOG, help="CSV output path")

    server = sub.add_parser(
        "serve", help="Rebuild the engine wheel, then serve web/ on localhost"
    )
    server.add_argument("--host", default=DEFAULT_HOST, help="Bind address (localhost only)")
    server.add_argument("--port", type=int, default=DEFAULT_PORT, help="Port")
    return parser


def rebuild_engine_wheel() -> int:
    """Rebuild the wheel the page loads, before serving the page that loads it.

    The browser imports `web/vendor/wheels/sentinel_lite.whl`, not `src/`, so an
    edit under `src/` is invisible until the wheel is rebuilt — and the test suite
    reads `src/` directly, so a stale wheel shows up as a browser that disagrees
    with a passing test. Building here means starting the dev server cannot serve
    a stale engine.

    Only present in a source checkout; an installed copy has no `tools/`, so a
    missing script is skipped rather than treated as a failure.
    """
    script = Path(__file__).resolve().parents[2] / "tools" / "build_engine_wheel.py"
    if not script.is_file():
        return 0
    return subprocess.run([sys.executable, str(script)]).returncode


def run_inventory(apex_path: Path, output_path: Path) -> int:
    if not apex_path.is_file():
        raise SystemExit(f"Apex file not found: {apex_path}")
    rows = load_inventory(apex_path)
    write_inventory_workbook(output_path, rows)
    system_count = sum(1 for row in rows if row.template == "system")
    programming_count = sum(1 for row in rows if row.template == "programming")
    unresolved = sum(1 for row in rows if row.unresolved)
    print(
        f"Wrote {output_path} — System {system_count} rows, "
        f"Programming {programming_count} rows ({unresolved} unresolved)"
    )
    return 0


def run_compare(previous_path: Path, current_path: Path, output_path: Path) -> int:
    if not previous_path.is_file() or not current_path.is_file():
        print(COMPARE_FAILED, file=sys.stderr)
        return 1
    try:
        result = compare_apex_files(previous_path, current_path)
        write_changelog_csv(output_path, result)
    except Exception:
        print(COMPARE_FAILED, file=sys.stderr)
        return 1
    if not result.entries:
        print(NO_CHANGES)
    else:
        print(f"Wrote {output_path} — {len(result.entries)} change(s)")
    return 0


def main(argv: list[str] | None = None) -> None:
    raw = list(sys.argv[1:] if argv is None else argv)
    if not raw or raw[0] not in COMMANDS:
        raw = ["inventory", *raw]
    args = build_parser().parse_args(raw)
    if args.command == "compare":
        raise SystemExit(run_compare(args.a.resolve(), args.b.resolve(), args.out.resolve()))
    if args.command == "serve":
        status = rebuild_engine_wheel()
        if status != 0:
            raise SystemExit(status)
        serve(host=args.host, port=args.port)
        return
    raise SystemExit(run_inventory(args.apex.resolve(), args.out.resolve()))


if __name__ == "__main__":
    main()
