"""Integer → name maps that are already locked. Do not add guessed entries."""

from __future__ import annotations

# Sentinel extractor_core._event_type_name — Events.EventType only (not RoomEvents).
PROCESSOR_EVENT_TYPE_NAMES: dict[int, str] = {
    1: "Sense",
    3: "Scheduled",
    4: "Startup",
    5: "Driver",
}

# RoomEvents.EventType → ID11 Selection / Deselection event names.
# Locked map (do not reopen 0/2/3/4/5): Haven/1790 Room ON/OFF + Video ON/OFF + Room Off Complete;
# Animo blue-wash Activity Start (ET4) + Room Off Start (ET5). Still unnamed: 1, 6.
# Deselection-tree labels Room Off Start / Complete use SelectedMacroId.
# Other Activities Events live elsewhere: Power On/Off → SourceEvents; Selected/Deselected/Ready → Activities.
ROOM_EVENT_SELECTED_NAMES: dict[int, str] = {
    0: "Room ON",
    2: "Video ON",
    3: "Room Off Complete",
    4: "Activity Start",
    5: "Room Off Start",
}
ROOM_EVENT_DESELECTED_NAMES: dict[int, str] = {
    0: "Room OFF",
    2: "Video OFF",
}

# Plan / Oracle provisional, accepted. Unknown stays "Unknown DeviceType n".
EXPANSION_DEVICE_TYPE_NAMES: dict[int, str] = {
    3: "ESC-2",
    5: "RCM-4",
    6: "XP-6",
    7: "RCM-12",
}

# Sentinel extractor_core._orientation_visibility / SupportedOrientations.
ORIENTATION_NAMES: dict[int, str] = {
    1: "Portrait",
    2: "Landscape",
    3: "Both Portrait and Landscape",
}
ORIENTATION_SUPPORT: dict[int, str] = {
    1: "portrait",
    2: "landscape",
    3: "both",
}

# Sentinel extractor_core._STYLE_TO_TYPE
BUTTON_STYLE_TYPES: dict[int, str] = {
    5: "Slider",
    6: "Image",
    7: "Toggle",
    9: "Slider",
    10: "Toggle",
    11: "LevelIndicatorBar",
    14: "Image",
}
RTSP_VIDEO_STYLE = 4

# Sentinel extractor_core hard-key frames
HARD_KEY_PHYSICAL_FRAME = 254
HARD_KEY_GESTURE_FRAME = 252

# Plan: one-file proven pairs only.
TIMEZONE_NAMES: dict[int, str] = {
    4: "(GMT-08:00) Pacific Time (US & Canada); Tijuana",
}
OUTPUT_TYPE_NAMES: dict[int, str] = {
    3: "Two-Way Trigger Codes",
}
TWO_WAY_TRANSPORT_NAMES: dict[int, str] = {
    2: "ZigBee",
}
SYSTEM_IR_PERIOD_NAMES: dict[int, str] = {
    25000: "40.0 KHz",
}

# Plan: PortLabels.LabelKey groups at processor RTIAddress=0
PORT_LABEL_GROUPS: tuple[tuple[int, int, str], ...] = (
    (-65536, -65529, "IR/MPIO"),
    (-65280, -65273, "RS-232"),
    (-65024, -65017, "Sense"),
    (-64768, -64761, "Relay"),
)

# Sentinel extractor_core._PAGE_LINK_NEXT_IN_GROUP_LINK_TYPES and LinkType 1
LINK_TYPE_NAMES: dict[int, str] = {
    1: "first page on device",
    2: "next in group",
}

# Plan: this-file proven Wake Up pair only (TiltSwitchEnabled=1, ProximityEnabled=0).
WAKE_UP_TILT_KEYPAD_TOUCHSCREEN = "Tilt Sensor, Keypad or Touchscreen"


def mapped_or_unresolved(mapping: dict[int, str], value: int | None, prefix: str) -> tuple[str, bool]:
    if value is None:
        return ("unresolved (null)", True)
    name = mapping.get(int(value))
    if name is None:
        return (f"{prefix} {int(value)}", True)
    return (name, False)


def port_label_group(label_key: int) -> str:
    for start, end, name in PORT_LABEL_GROUPS:
        if start <= int(label_key) <= end:
            return name
    return f"unresolved LabelKey {label_key}"


def flag_label(variable_index: int) -> str:
    # Plan: Flag 001 = VariableIndex 0
    return f"Flag {int(variable_index) + 1:03d}"
