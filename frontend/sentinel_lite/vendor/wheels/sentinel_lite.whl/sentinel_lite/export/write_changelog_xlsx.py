from __future__ import annotations

import re
import zipfile
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from sentinel_lite.compare.format import plain_line

# Headers follow the two locked line templates (plus Tested? / Kind / Change / Notes).
SYSTEM_COLUMNS: tuple[str, ...] = (
    "Tested?",
    "Place",
    "Branch",
    "Name",
    "Pane",
    "Item",
    "Kind",
    "Change",
    "Notes",
)
PROGRAMMING_COLUMNS: tuple[str, ...] = (
    "Tested?",
    "Device",
    "Source",
    "Page",
    "Page Layer",
    "Viewport Layer",
    "Type",
    "Identity",
    "Kind",
    "Change",
    "Notes",
)

# Optional System path insert before Name (same as format._SYSTEM_BRANCH_INSERTS).
_SYSTEM_BRANCH_LABELS: tuple[str, ...] = ("Drivers", "Controllers", "Sources", "Activities")

_HEADER_FILL = PatternFill("solid", fgColor="58585A")
_HEADER_FONT = Font(color="FFFFFF", bold=True)
_HEADER_ALIGN = Alignment(vertical="center", wrap_text=True)
_WRAP = Alignment(vertical="top", wrap_text=True)
_TESTED_ALIGN = Alignment(horizontal="center", vertical="center")
_KIND_FILLS: dict[str, PatternFill] = {
    "added": PatternFill("solid", fgColor="C6E9CB"),
    "changed": PatternFill("solid", fgColor="FCE4B8"),
    "removed": PatternFill("solid", fgColor="F5C6C6"),
}
_FILTER_ALL = "All (no exclusions)"
_COLUMN_WIDTHS: dict[str, float] = {
    "Tested?": 10,
    "Place": 14,
    "Branch": 14,
    "Name": 22,
    "Pane": 22,
    "Item": 22,
    "Device": 14,
    "Source": 18,
    "Page": 18,
    "Page Layer": 16,
    "Viewport Layer": 16,
    "Type": 14,
    "Identity": 22,
    "Kind": 12,
    "Change": 40,
    "Notes": 24,
}

_SSML = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_FEATURE_BAG_REL = (
    "http://schemas.microsoft.com/office/2022/11/relationships/FeaturePropertyBag"
)
_FEATURE_BAG_CONTENT = "application/vnd.ms-excel.featurepropertybag+xml"
_FEATURE_BAG_PATH = "xl/featurePropertyBag/featurePropertyBag.xml"
_CHECKBOX_SHEETS = ("System", "Programming")
_FEATURE_BAG_XML = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
    '<FeaturePropertyBags xmlns="http://schemas.microsoft.com/office/'
    'spreadsheetml/2022/featurepropertybag">'
    '<bag type="Checkbox"/>'
    '<bag type="XFControls"><bagId k="CellControl">0</bagId></bag>'
    '<bag type="XFComplement"><bagId k="XFControls">1</bagId></bag>'
    '<bag type="XFComplements" extRef="XFComplementsMapperExtRef">'
    '<a k="MappedFeaturePropertyBags"><bagId>2</bagId></a></bag>'
    "</FeaturePropertyBags>"
)
_CHECKBOX_XF = (
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" '
    'applyAlignment="1">'
    '<alignment horizontal="center" vertical="center"/>'
    "<extLst>"
    '<ext uri="{C7286773-470A-42A8-94C5-96B5CB345126}" '
    'xmlns:xfpb="http://schemas.microsoft.com/office/spreadsheetml/'
    '2022/featurepropertybag">'
    '<xfpb:xfComplement i="0"/>'
    "</ext>"
    "</extLst>"
    "</xf>"
)


@dataclass(frozen=True)
class ChangelogExportMeta:
    previous_file: str = ""
    current_file: str = ""
    system_name: str = ""
    place_order: tuple[str, ...] = ()
    total_count: int | None = None
    exported_at: str = ""
    chart_chip: str = ""
    filter_exclusions: tuple[str, ...] = ()


def change_suffix(entry: Mapping[str, Any]) -> str:
    """Verb + details after the path (plain)."""
    plain = plain_line(str(entry.get("line") or ""))
    if " : " in plain:
        return plain.split(" : ", 1)[1]
    return plain


def build_changelog_workbook(
    entries: Sequence[Mapping[str, Any]],
    meta: ChangelogExportMeta,
) -> Workbook:
    ordered = _ordered_entries(entries, meta.place_order)
    system_rows = [row for row in ordered if (row.get("template") or "system") != "programming"]
    programming_rows = [row for row in ordered if (row.get("template") or "") == "programming"]

    workbook = Workbook()
    summary = workbook.active
    summary.title = "Summary"
    _write_summary(summary, meta, visible_count=len(ordered))

    system_sheet = workbook.create_sheet("System")
    _write_change_sheet(system_sheet, SYSTEM_COLUMNS, system_rows, _system_values)

    programming_sheet = workbook.create_sheet("Programming")
    _write_change_sheet(
        programming_sheet,
        PROGRAMMING_COLUMNS,
        programming_rows,
        _programming_values,
    )
    return workbook


def write_changelog_xlsx(
    path: Path,
    entries: Sequence[Mapping[str, Any]],
    meta: ChangelogExportMeta,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(write_changelog_xlsx_bytes(entries, meta))


def write_changelog_xlsx_bytes(
    entries: Sequence[Mapping[str, Any]],
    meta: ChangelogExportMeta,
) -> bytes:
    workbook = build_changelog_workbook(entries, meta)
    buffer = BytesIO()
    workbook.save(buffer)
    return _inject_tested_checkboxes(buffer.getvalue())


def meta_from_payload(payload: Mapping[str, Any]) -> ChangelogExportMeta:
    place_order_raw = payload.get("placeOrder") or ()
    place_order = tuple(str(place) for place in place_order_raw)
    total = payload.get("totalCount")
    total_count = int(total) if total is not None else None
    exclusions_raw = payload.get("filterExclusions") or ()
    exclusions = tuple(str(item).strip() for item in exclusions_raw if str(item).strip())
    return ChangelogExportMeta(
        previous_file=str(payload.get("previousFile") or ""),
        current_file=str(payload.get("currentFile") or ""),
        system_name=str(payload.get("systemName") or ""),
        place_order=place_order,
        total_count=total_count,
        exported_at=str(payload.get("exportedAt") or ""),
        chart_chip=str(payload.get("chartChip") or "").strip() or "none",
        filter_exclusions=exclusions,
    )


def filter_summary_text(exclusions: Sequence[str]) -> str:
    """Compact Summary value — unchecked cut points, or all-on."""
    cleaned = [str(item).strip() for item in exclusions if str(item).strip()]
    if not cleaned:
        return _FILTER_ALL
    return "\n".join(cleaned)


def _ordered_entries(
    entries: Sequence[Mapping[str, Any]],
    place_order: Sequence[str],
) -> list[Mapping[str, Any]]:
    present = {str(entry.get("place") or "") for entry in entries}
    ordered_places: list[str] = []
    for place in place_order:
        if place in present and place not in ordered_places:
            ordered_places.append(place)
    for place in present:
        if place and place not in ordered_places:
            ordered_places.append(place)
    if "Global" in ordered_places:
        ordered_places = ["Global", *[p for p in ordered_places if p != "Global"]]

    rank = {place: index for index, place in enumerate(ordered_places)}
    indexed = list(enumerate(entries))
    indexed.sort(key=lambda pair: (rank.get(str(pair[1].get("place") or ""), 10_000), pair[0]))
    return [entry for _, entry in indexed]


def _segments_by_label(entry: Mapping[str, Any]) -> dict[str, str]:
    out: dict[str, str] = {}
    for segment in entry.get("segments") or ():
        if isinstance(segment, Mapping):
            label = str(segment.get("label") or "").strip()
            text = plain_line(str(segment.get("text") or "").strip())
        elif isinstance(segment, (tuple, list)) and len(segment) >= 2:
            label = str(segment[0] or "").strip()
            text = plain_line(str(segment[1] or "").strip())
        else:
            continue
        if label and label not in out:
            out[label] = text
    return out


def _system_values(entry: Mapping[str, Any]) -> list[Any]:
    segs = _segments_by_label(entry)
    branch = ""
    for label in _SYSTEM_BRANCH_LABELS:
        if label in segs:
            branch = segs[label]
            break
    name = segs.get("Name") or ""
    if not name:
        name = str(entry.get("source") or entry.get("driver") or "").strip()
    return [
        False,
        segs.get("Place") or str(entry.get("place") or ""),
        branch,
        name,
        segs.get("Pane", ""),
        segs.get("Item", ""),
        str(entry.get("kind") or "").strip(),
        change_suffix(entry),
        "",
    ]


def _programming_values(entry: Mapping[str, Any]) -> list[Any]:
    segs = _segments_by_label(entry)
    return [
        False,
        segs.get("Device", ""),
        segs.get("Source", ""),
        segs.get("Page", ""),
        segs.get("Page Layer", ""),
        segs.get("Viewport Layer", ""),
        segs.get("Type", ""),
        segs.get("Identity", ""),
        str(entry.get("kind") or "").strip(),
        change_suffix(entry),
        "",
    ]


def _write_summary(sheet: Worksheet, meta: ChangelogExportMeta, *, visible_count: int) -> None:
    chip = meta.chart_chip.strip() or "none"
    rows = [
        ("System name", meta.system_name),
        ("Previous file", meta.previous_file),
        ("Current file", meta.current_file),
        ("Exported", meta.exported_at),
        ("Visible rows", str(visible_count)),
    ]
    if meta.total_count is not None:
        rows.append(("Compare total", str(meta.total_count)))
    rows.append(("Chart chip", chip))
    rows.append(("Filter", filter_summary_text(meta.filter_exclusions)))

    sheet.append(["Field", "Value"])
    for cell in sheet[1]:
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = _HEADER_ALIGN
    for field, value in rows:
        sheet.append([field, value])
        if field == "Filter":
            sheet.cell(sheet.max_row, 2).alignment = _WRAP
    sheet.freeze_panes = "A2"
    sheet.column_dimensions["A"].width = 18
    sheet.column_dimensions["B"].width = 56


def _write_change_sheet(
    sheet: Worksheet,
    columns: tuple[str, ...],
    entries: Sequence[Mapping[str, Any]],
    values_for: Callable[[Mapping[str, Any]], list[Any]],
) -> None:
    sheet.append(list(columns))
    for cell in sheet[1]:
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = _HEADER_ALIGN
    sheet.freeze_panes = "A2"
    sheet.row_dimensions[1].height = 22

    kind_col = columns.index("Kind") + 1
    change_col = columns.index("Change") + 1
    tested_col = columns.index("Tested?") + 1

    for entry in entries:
        values = values_for(entry)
        kind = values[kind_col - 1]
        sheet.append(values)
        row_number = sheet.max_row
        fill = _KIND_FILLS.get(str(kind))
        if fill is not None:
            sheet.cell(row_number, kind_col).fill = fill
        sheet.cell(row_number, change_col).alignment = _WRAP
        tested = sheet.cell(row_number, tested_col)
        tested.value = False
        tested.alignment = _TESTED_ALIGN

    last_row = max(sheet.max_row, 1)
    sheet.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{last_row}"
    _fit_column_widths(sheet, columns)


def _fit_column_widths(sheet: Worksheet, columns: tuple[str, ...]) -> None:
    for index, column_name in enumerate(columns, start=1):
        width = _COLUMN_WIDTHS.get(column_name, 16)
        sheet.column_dimensions[get_column_letter(index)].width = width


def _inject_tested_checkboxes(data: bytes) -> bytes:
    """Turn boolean Tested? cells into Excel 365 in-cell checkboxes."""
    ET.register_namespace("", _SSML)
    with zipfile.ZipFile(BytesIO(data), "r") as source:
        parts = {name: source.read(name) for name in source.namelist()}

    style_index = _append_checkbox_style(parts)
    for sheet_name in _CHECKBOX_SHEETS:
        sheet_path = _sheet_path(parts, sheet_name)
        if sheet_path is None:
            continue
        parts[sheet_path] = _apply_checkbox_style(parts[sheet_path], style_index)

    parts[_FEATURE_BAG_PATH] = _FEATURE_BAG_XML.encode("utf-8")
    parts["[Content_Types].xml"] = _ensure_feature_bag_content_type(
        parts["[Content_Types].xml"]
    )
    parts["xl/_rels/workbook.xml.rels"] = _ensure_feature_bag_relationship(
        parts["xl/_rels/workbook.xml.rels"]
    )

    output = BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as target:
        for name, payload in parts.items():
            target.writestr(name, payload)
    return output.getvalue()


def _append_checkbox_style(parts: dict[str, bytes]) -> int:
    styles = parts["xl/styles.xml"].decode("utf-8")
    match = re.search(r'<cellXfs[^>]*count="(\d+)"[^>]*>', styles)
    if match is None:
        raise ValueError("styles.xml is missing cellXfs")
    count = int(match.group(1))
    styles = styles.replace(
        match.group(0),
        match.group(0).replace(f'count="{count}"', f'count="{count + 1}"', 1),
        1,
    )
    close = "</cellXfs>"
    if close not in styles:
        raise ValueError("styles.xml is missing </cellXfs>")
    styles = styles.replace(close, _CHECKBOX_XF + close, 1)
    parts["xl/styles.xml"] = styles.encode("utf-8")
    return count


def _sheet_path(parts: Mapping[str, bytes], title: str) -> str | None:
    workbook = ET.fromstring(parts["xl/workbook.xml"])
    rels = ET.fromstring(parts["xl/_rels/workbook.xml.rels"])
    rel_by_id = {
        rel.attrib["Id"]: rel.attrib["Target"]
        for rel in rels
        if rel.attrib.get("Id") and rel.attrib.get("Target")
    }
    for sheet in workbook.findall(f"{{{_SSML}}}sheets/{{{_SSML}}}sheet"):
        if sheet.attrib.get("name") != title:
            continue
        rel_id = sheet.attrib.get(
            "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
        )
        target = rel_by_id.get(rel_id or "")
        if not target:
            return None
        cleaned = target.lstrip("/")
        if cleaned.startswith("xl/"):
            return cleaned
        return f"xl/{cleaned}"
    return None


def _apply_checkbox_style(sheet_xml: bytes, style_index: int) -> bytes:
    text = sheet_xml.decode("utf-8")

    def rewrite(match: re.Match[str]) -> str:
        cell = match.group(0)
        if ' t="b"' not in cell and " t='b'" not in cell:
            return cell
        if re.search(r'\bs="\d+"', cell):
            return re.sub(r'\bs="\d+"', f's="{style_index}"', cell, count=1)
        return cell.replace("<c ", f'<c s="{style_index}" ', 1)

    # Column A data rows only (header stays plain text).
    return re.sub(r'<c r="A[2-9]\d*"[^>]*>.*?</c>', rewrite, text, flags=re.DOTALL).encode(
        "utf-8"
    )


def _ensure_feature_bag_content_type(content_types: bytes) -> bytes:
    text = content_types.decode("utf-8")
    if "featurePropertyBag.xml" in text:
        return content_types
    override = (
        f'<Override PartName="/{_FEATURE_BAG_PATH}" ContentType="{_FEATURE_BAG_CONTENT}"/>'
    )
    return text.replace("</Types>", override + "</Types>", 1).encode("utf-8")


def _ensure_feature_bag_relationship(rels_xml: bytes) -> bytes:
    text = rels_xml.decode("utf-8")
    if "FeaturePropertyBag" in text:
        return rels_xml
    used = {int(match) for match in re.findall(r'Id="rId(\d+)"', text)}
    next_id = max(used, default=0) + 1
    relationship = (
        f'<Relationship Id="rId{next_id}" Type="{_FEATURE_BAG_REL}" '
        f'Target="featurePropertyBag/featurePropertyBag.xml"/>'
    )
    return text.replace("</Relationships>", relationship + "</Relationships>", 1).encode(
        "utf-8"
    )
