"""Breakdown PDF from live UI HTML (Playwright / Chromium)."""

from __future__ import annotations

import base64
import re
from pathlib import Path
from typing import Any


def write_breakdown_pdf_from_html(
    html: str,
    *,
    base_url: str = "",
    web_root: Path | None = None,
) -> bytes:
    """Render a self-contained breakdown document to Letter portrait PDF."""
    text = str(html or "").strip()
    if not text:
        raise ValueError("html")
    root = web_root
    if root is None and base_url.startswith("file:"):
        # file:///…/web/ → Path
        from urllib.parse import urlparse, unquote

        parsed = urlparse(base_url)
        candidate = Path(unquote(parsed.path))
        if candidate.name == "" or str(base_url).endswith("/"):
            root = candidate
        else:
            root = candidate.parent
    if root is not None:
        text = _inline_web_assets(text, Path(root))

    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "playwright is required for PDF export — pip install playwright "
            "&& playwright install chromium"
        ) from exc

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch()
        try:
            page = browser.new_page()
            page.set_content(text, wait_until="load")
            page.evaluate(
                """async () => {
                  if (document.fonts && document.fonts.ready) {
                    await document.fonts.ready;
                  }
                }"""
            )
            return page.pdf(
                format="Letter",
                landscape=False,
                print_background=True,
                margin={
                    "top": "0.35in",
                    "right": "0.4in",
                    "bottom": "0.35in",
                    "left": "0.4in",
                },
            )
        finally:
            browser.close()


def write_breakdown_pdf_bytes(
    payload: dict[str, Any] | str,
    base_url: str = "",
    web_root: Path | None = None,
) -> bytes:
    """Accept raw HTML string or `{html, baseUrl}` payload."""
    if isinstance(payload, str):
        return write_breakdown_pdf_from_html(
            payload, base_url=base_url, web_root=web_root
        )
    html = payload.get("html")
    if not isinstance(html, str):
        raise ValueError("html")
    resolved = str(payload.get("baseUrl") or base_url or "").strip()
    return write_breakdown_pdf_from_html(
        html, base_url=resolved, web_root=web_root
    )


def _inline_web_assets(html: str, web_root: Path) -> str:
    """Embed styles.css / pdf_export.css / logo so Chromium does not need network."""
    root = web_root.resolve()
    styles = _read_text(root / "styles.css")
    pdf_css = _read_text(root / "pdf_export.css")
    logo = root / "assets" / "feeny-logo.png"
    logo_uri = ""
    if logo.is_file():
        encoded = base64.b64encode(logo.read_bytes()).decode("ascii")
        logo_uri = f"data:image/png;base64,{encoded}"

    # Strip external stylesheet links we are replacing.
    out = re.sub(
        r'<link[^>]+href=["\'][^"\']*styles\.css["\'][^>]*>\s*',
        "",
        html,
        flags=re.I,
    )
    out = re.sub(
        r'<link[^>]+href=["\'][^"\']*pdf_export\.css["\'][^>]*>\s*',
        "",
        out,
        flags=re.I,
    )
    style_block = f"<style>\n{styles}\n{pdf_css}\n</style>"
    if re.search(r"<head[^>]*>", out, flags=re.I):
        out = re.sub(r"<head([^>]*)>", rf"<head\1>{style_block}", out, count=1, flags=re.I)
    else:
        out = f"<head>{style_block}</head>{out}"

    if logo_uri:
        out = re.sub(
            r'(<img[^>]+class=["\'][^"\']*brand-logo[^"\']*["\'][^>]+src=["\'])[^"\']+(["\'])',
            rf"\1{logo_uri}\2",
            out,
            flags=re.I,
        )
        out = re.sub(
            r'(<img[^>]+src=["\'])[^"\']*feeny-logo\.png(["\'])',
            rf"\1{logo_uri}\2",
            out,
            count=1,
            flags=re.I,
        )
    return out


def _read_text(path: Path) -> str:
    if not path.is_file():
        return ""
    return path.read_text(encoding="utf-8")
