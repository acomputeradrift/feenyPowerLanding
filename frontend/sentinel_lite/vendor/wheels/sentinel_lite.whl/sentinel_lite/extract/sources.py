"""Source identity rows — Devices.Name (distinct from activity DisplayName)."""

from __future__ import annotations

import sqlite3

from sentinel_lite.apex_db import table_exists
from sentinel_lite.extract.helpers import mark_unresolved, system_row
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.catalog import NameCatalog


def extract_sources(connection: sqlite3.Connection, catalog: NameCatalog) -> list[InventoryRow]:
    """One identity row per source device (page owner and/or activity device)."""
    device_ids: set[int] = set()
    if table_exists(connection, "Activities"):
        for row in connection.execute("select distinct DeviceId from Activities where DeviceId is not null"):
            device_ids.add(int(row["DeviceId"] or 0))
    if table_exists(connection, "RTIDevicePageData"):
        for row in connection.execute(
            "select distinct SourceDeviceId from RTIDevicePageData where SourceDeviceId is not null"
        ):
            device_ids.add(int(row["SourceDeviceId"] or 0))
    elif table_exists(connection, "PagesView"):
        for row in connection.execute(
            "select distinct SourceDeviceId from PagesView where SourceDeviceId is not null"
        ):
            device_ids.add(int(row["SourceDeviceId"] or 0))
    device_ids.discard(0)

    rows: list[InventoryRow] = []
    for device_id in sorted(device_ids):
        room_id = catalog.device_room_by_id.get(device_id, 0)
        place = catalog.room_name(room_id) if room_id else "Global"
        source = catalog.source_name(device_id)
        order = catalog.device_display_order_by_id.get(device_id, device_id)
        rows.append(
            system_row(
                sort_key=f"20.{room_id:03d}.50.{order:04d}.{device_id}.identity",
                section=f"{place} / Sources / {source}",
                place=place,
                object_name=source,
                details="",
                source_table="Devices",
                source_key=f"source.{device_id}",
                unresolved=mark_unresolved(place, source),
            )
        )
    return rows
