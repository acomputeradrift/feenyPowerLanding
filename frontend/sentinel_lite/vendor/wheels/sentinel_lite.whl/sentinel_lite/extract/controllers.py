from __future__ import annotations

import sqlite3

from sentinel_lite.extract.flags import extract_flag_names
from sentinel_lite.extract.helpers import mark_unresolved, system_row
from sentinel_lite.locked_maps import (
    ORIENTATION_NAMES,
    OUTPUT_TYPE_NAMES,
    SYSTEM_IR_PERIOD_NAMES,
    TIMEZONE_NAMES,
    TWO_WAY_TRANSPORT_NAMES,
    WAKE_UP_TILT_KEYPAD_TOUCHSCREEN,
    default_sound_label,
    mapped_or_unresolved,
)
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.catalog import NameCatalog
from sentinel_lite.resolve.ipv4 import dotted_ipv4_from_signed_int
from sentinel_lite.secrets import redact_value


def extract_controllers(connection: sqlite3.Connection, catalog: NameCatalog) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    for device in connection.execute(
        """
        select rd.*, d.DisplayName, d.Name, d.RoomId
        from RTIDeviceData rd
        left join Devices d on d.DeviceId = rd.DeviceId
        where rd.RTIAddress != 0
        order by rd.RTIAddress
        """
    ):
        rows.extend(_one_controller(connection, catalog, device))
    return rows


def _one_controller(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    device: sqlite3.Row,
) -> list[InventoryRow]:
    rti = int(device["RTIAddress"])
    room_id = int(device["RoomId"] or 0)
    place = catalog.room_name(room_id) if room_id else "Global"
    name = catalog.controller_name(rti)
    sort_base = f"20.{room_id:03d}.40.{rti:03d}" if room_id else f"01.04.{rti:03d}"
    rows: list[InventoryRow] = [
        system_row(
            sort_key=f"{sort_base}.identity",
            section=f"{place} / {name}",
            place=place,
            object_name=name,
            details=f"RTIAddress={rti}; CloneRTIAddress={device['CloneRTIAddress']}",
            source_table="RTIDeviceData",
            source_key=str(rti),
            unresolved=mark_unresolved(name, place),
        )
    ]
    product = str(device["Name"] or "") + " " + str(device["DisplayName"] or "")
    is_t2x = "T2x" in product or "T2x" in name
    is_rtipanel = "RTiPanel" in product or "RTiPanel" in name or "iPhone" in product
    if is_rtipanel:
        rows.extend(_rtipanel_properties(device, place, name, sort_base))
    if is_t2x:
        rows.extend(_t2x_properties(device, place, name, sort_base))
        rows.extend(
            extract_flag_names(
                connection,
                rti_address=rti,
                place=place,
                object_name=name,
                sort_base=sort_base,
            )
        )
    rows.extend(_room_list(connection, catalog, rti, place, name, sort_base))
    return rows


def _prop(
    place: str,
    name: str,
    sort_base: str,
    pane: str,
    item: str,
    details: object,
    source_key: str,
    unresolved: str = "",
) -> InventoryRow:
    return system_row(
        sort_key=f"{sort_base}.{pane}.{item}",
        section=f"{place} / {name} / Properties / {pane}",
        place=place,
        object_name=name,
        pane=f"Properties / {pane}",
        item=item,
        details=str(redact_value(item, details)),
        source_table="RTIDeviceData",
        source_key=source_key,
        unresolved=unresolved,
    )


def _rtipanel_properties(device: sqlite3.Row, place: str, name: str, sort_base: str) -> list[InventoryRow]:
    rti = int(device["RTIAddress"])
    orientation, unresolved = mapped_or_unresolved(
        ORIENTATION_NAMES, int(device["SupportedOrientations"] or 0), "SupportedOrientations"
    )
    return [
        _prop(place, name, sort_base, "General", "Supported Orientations", orientation, f"{rti}.SupportedOrientations", "unresolved" if unresolved else ""),
        _prop(place, name, sort_base, "Sounds", "Enable Button Press Sounds", device["BeeperMode"], f"{rti}.BeeperMode"),
        _prop(place, name, sort_base, "Sounds", "Default Sound Index", default_sound_label(device["DefaultSoundIndex"]), f"{rti}.DefaultSoundIndex"),
        _prop(place, name, sort_base, "Security", "Passcode", redact_value("Passcode", device["Passcode"]), f"{rti}.Passcode"),
        _prop(place, name, sort_base, "VoIP", "VoIP Enable", device["VoipEnable"], f"{rti}.VoipEnable"),
        _prop(place, name, sort_base, "VoIP", "Caller ID", device["VoipCallerID"], f"{rti}.VoipCallerID"),
        _prop(place, name, sort_base, "VoIP", "DND", device["VoipDND"], f"{rti}.VoipDND"),
        _prop(place, name, sort_base, "VoIP", "Auto Answer", device["VoipAutoAnswer"], f"{rti}.VoipAutoAnswer"),
        _prop(place, name, sort_base, "VoIP", "Auto Answer Ring", device["VoipAutoAnswerRing"], f"{rti}.VoipAutoAnswerRing"),
        _prop(place, name, sort_base, "VoIP", "Video Auto Receive", device["VoipVideoAutoReceive"], f"{rti}.VoipVideoAutoReceive"),
        _prop(place, name, sort_base, "VoIP-SIP", "Registrar Enable", device["VoipSipRegistrarEnable"], f"{rti}.VoipSipRegistrarEnable"),
        _prop(place, name, sort_base, "VoIP-SIP", "Registrar Address", device["VoipSipRegistrarAddress"], f"{rti}.VoipSipRegistrarAddress"),
        _prop(place, name, sort_base, "VoIP-SIP", "Registrar Port", device["VoipSipRegistrarPort"], f"{rti}.VoipSipRegistrarPort"),
        _prop(place, name, sort_base, "VoIP-SIP", "Username", redact_value("Username", device["VoipSipUsername"]), f"{rti}.VoipSipUsername"),
        _prop(place, name, sort_base, "VoIP-SIP", "Password", redact_value("Password", device["VoipSipPassword"]), f"{rti}.VoipSipPassword"),
    ]


def _t2x_properties(device: sqlite3.Row, place: str, name: str, sort_base: str) -> list[InventoryRow]:
    rti = int(device["RTIAddress"])
    tilt = int(device["TiltSwitchEnabled"] or 0)
    proximity = int(device["ProximityEnabled"] or 0)
    if tilt == 1 and proximity == 0:
        wake, wake_unresolved = WAKE_UP_TILT_KEYPAD_TOUCHSCREEN, ""
    else:
        wake, wake_unresolved = f"TiltSwitchEnabled={tilt}; ProximityEnabled={proximity}", "unresolved Wake Up encoding"
    output, out_u = mapped_or_unresolved(OUTPUT_TYPE_NAMES, int(device["OutputType"] or 0), "OutputType")
    transport, tr_u = mapped_or_unresolved(TWO_WAY_TRANSPORT_NAMES, int(device["TwoWayTransport"] or 0), "TwoWayTransport")
    ir, ir_u = mapped_or_unresolved(SYSTEM_IR_PERIOD_NAMES, int(device["SystemIrPeriod"] or 0), "SystemIrPeriod")
    timezone, tz_u = mapped_or_unresolved(TIMEZONE_NAMES, int(device["TimeZone"] or 0), "TimeZone")
    return [
        _prop(place, name, sort_base, "Backlight", "ALS Enabled", device["AlsEnabled"], f"{rti}.AlsEnabled"),
        _prop(place, name, sort_base, "Backlight", "Backlight ALS Bright", device["BacklightLevelAlsBright"], f"{rti}.BacklightLevelAlsBright"),
        _prop(place, name, sort_base, "Backlight", "Backlight ALS Dark", device["BacklightLevelAlsDark"], f"{rti}.BacklightLevelAlsDark"),
        _prop(place, name, sort_base, "Backlight", "Power Down Seconds", device["PowerDown"], f"{rti}.PowerDown"),
        _prop(place, name, sort_base, "Backlight", "Wake Up Sources", wake, f"{rti}.WakeUp", wake_unresolved),
        _prop(place, name, sort_base, "Sounds", "Volume Level", device["VolumeLevel"], f"{rti}.VolumeLevel"),
        _prop(place, name, sort_base, "Sounds", "Enable Button Press Sounds", device["BeeperMode"], f"{rti}.BeeperMode"),
        _prop(place, name, sort_base, "Sounds", "Default Sound Index", default_sound_label(device["DefaultSoundIndex"]), f"{rti}.DefaultSoundIndex"),
        _prop(place, name, sort_base, "Wireless Network", "Use DHCP", device["NetUseDhcp"], f"{rti}.NetUseDhcp"),
        _prop(place, name, sort_base, "Wireless Network", "IP Address", dotted_ipv4_from_signed_int(device["IpaddressAdapter0"]), f"{rti}.IpaddressAdapter0"),
        _prop(place, name, sort_base, "Wireless Network", "Subnet Mask", dotted_ipv4_from_signed_int(device["NetmaskAdapter0"]), f"{rti}.NetmaskAdapter0"),
        _prop(place, name, sort_base, "Wireless Network", "Gateway", dotted_ipv4_from_signed_int(device["GatewayAdapter0"]), f"{rti}.GatewayAdapter0"),
        _prop(place, name, sort_base, "Wireless Network", "DNS 1", dotted_ipv4_from_signed_int(device["Dns1Adapter0"]), f"{rti}.Dns1Adapter0"),
        _prop(place, name, sort_base, "Wireless Network", "DNS 2", dotted_ipv4_from_signed_int(device["Dns2Adapter0"]), f"{rti}.Dns2Adapter0"),
        _prop(place, name, sort_base, "802.11", "Use System Default", device["UseNetworkDefaults"], f"{rti}.UseNetworkDefaults"),
        _prop(place, name, sort_base, "802.11", "Enable Wireless Network Adapter", device["EnableWlan"], f"{rti}.EnableWlan"),
        _prop(place, name, sort_base, "802.11", "Enable Wireless LAN Status LED", device["EnableWlanLed"], f"{rti}.EnableWlanLed"),
        _prop(place, name, sort_base, "Clock", "Use Clock Defaults", device["UseClockDefaults"], f"{rti}.UseClockDefaults"),
        _prop(place, name, sort_base, "Clock", "Time Zone", timezone, f"{rti}.TimeZone", "unresolved" if tz_u else ""),
        _prop(place, name, sort_base, "Output", "Output Type", output, f"{rti}.OutputType", "unresolved" if out_u else ""),
        _prop(place, name, sort_base, "Output", "Two-Way Transport", transport, f"{rti}.TwoWayTransport", "unresolved" if tr_u else ""),
        _prop(place, name, sort_base, "Output", "System IR Period", ir, f"{rti}.SystemIrPeriod", "unresolved" if ir_u else ""),
    ]


def _room_list(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    rti: int,
    place: str,
    name: str,
    sort_base: str,
) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    for row in connection.execute(
        "select RoomId, ControllerRoomOrder from ControllerRoomList where RTIAddress = ? order by ControllerRoomOrder",
        (rti,),
    ):
        room = catalog.room_name(int(row["RoomId"]))
        rows.append(
            system_row(
                sort_key=f"{sort_base}.RoomList.{int(row['ControllerRoomOrder']):03d}",
                section=f"{place} / {name} / Room List",
                place=place,
                object_name=name,
                pane="Room List",
                item=room,
                details=f"ControllerRoomOrder={row['ControllerRoomOrder']}",
                source_table="ControllerRoomList",
                source_key=f"{rti}.{row['RoomId']}",
                unresolved=mark_unresolved(room),
            )
        )
    return rows
