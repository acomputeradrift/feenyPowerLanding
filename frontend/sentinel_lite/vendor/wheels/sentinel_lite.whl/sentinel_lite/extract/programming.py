from __future__ import annotations

import sqlite3
from collections import defaultdict

from sentinel_lite.apex_db import table_exists
from sentinel_lite.extract.helpers import mark_unresolved
from sentinel_lite.locked_maps import LINK_TYPE_NAMES, RTSP_VIDEO_STYLE, mapped_or_unresolved
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.button_identity import (
    button_identity,
    display_button_text,
    has_button_bitmap_or_icon,
    positive_tag_id,
    usable_name,
)
from sentinel_lite.resolve.button_type import classify_button_type, empty_tag_type
from sentinel_lite.resolve.catalog import NameCatalog
from sentinel_lite.resolve.tag_scope import encode_scope_from_ids, format_macro_scope


def extract_programming(connection: sqlite3.Connection, catalog: NameCatalog) -> list[InventoryRow]:
    pages = list(
        connection.execute(
            """
            select PageId, PageName, RoomId, SourceDeviceId, RTIAddress, PageOrder, PageNameId, HiddenPage
            from PagesView
            order by RTIAddress, PageOrder, PageId
            """
        )
    )
    layers_by_page: dict[int, list[sqlite3.Row]] = defaultdict(list)
    children_by_host: dict[int, list[sqlite3.Row]] = defaultdict(list)
    for row in connection.execute(
        """
        select LayerId, PageId, SourceId, SharedLayerId, LayerOrder, ViewPortButtonId, RoomId,
               VisibilityVariable, IsLocked
        from Layers
        order by LayerOrder, LayerId
        """
    ):
        # Viewport children have PageId null. Parent them through ViewPortButtonId
        # → host button → the page layer that owns that button (Sentinel _resolve_viewport_frames).
        if row["ViewPortButtonId"] is not None:
            children_by_host[int(row["ViewPortButtonId"])].append(row)
        elif row["PageId"] is not None:
            layers_by_page[int(row["PageId"])].append(row)

    buttons_by_shared: dict[int, list[sqlite3.Row]] = defaultdict(list)
    button_sql = (
        "select * from LayerButtons"
        if table_exists(connection, "LayerButtons")
        else "select * from RTIDeviceButtonData"
    )
    seen_button_on_layer: set[tuple[int, int]] = set()
    for row in connection.execute(button_sql):
        shared_id = int(row["SharedLayerId"] or 0)
        button_id = int(row["ButtonId"])
        key = (shared_id, button_id)
        if key in seen_button_on_layer:
            continue
        seen_button_on_layer.add(key)
        buttons_by_shared[shared_id].append(row)

    variables_by_tag: dict[int, list[sqlite3.Row]] = defaultdict(list)
    for row in connection.execute("select VariableId, RoomId, DeviceId, ButtonTagId from Variables"):
        tag_id = positive_tag_id(row["ButtonTagId"])
        if tag_id:
            variables_by_tag[tag_id].append(row)

    macros_by_tag: dict[int, list[sqlite3.Row]] = defaultdict(list)
    for row in connection.execute("select MacroId, RoomId, DeviceId, ButtonTagId from Macros"):
        tag_id = positive_tag_id(row["ButtonTagId"])
        if tag_id:
            macros_by_tag[tag_id].append(row)

    # Empty GlobalMacroId placeholders (1790: MacroId 856 / SystemMacroId 202) have 0 steps.
    macros_with_steps = {
        int(row[0]) for row in connection.execute("select distinct MacroId from MacroSteps")
    }

    page_links_by_tag: dict[tuple[int, int], sqlite3.Row] = {}
    for row in connection.execute("select PageLinkId, DeviceId, ButtonTagId, LinkType, PageId from PageLinks"):
        tag_id = positive_tag_id(row["ButtonTagId"])
        if not tag_id:
            continue
        page_links_by_tag[(int(row["DeviceId"] or 0), tag_id)] = row

    viewport_hosts: set[int] = set()
    for row in connection.execute("select distinct ViewPortButtonId from Layers where ViewPortButtonId is not null"):
        viewport_hosts.add(int(row["ViewPortButtonId"]))

    rows: list[InventoryRow] = []
    for page in pages:
        page_id = int(page["PageId"])
        rti = int(page["RTIAddress"])
        device = catalog.controller_name(rti)
        source = catalog.source_name(int(page["SourceDeviceId"]))
        page_name = str(page["PageName"] or "").strip() or catalog.page_name(page_id)
        place = catalog.room_name(int(page["RoomId"] or 0))
        rows.append(
            InventoryRow(
                sort_key=f"90.{rti:03d}.{int(page['PageOrder'] or 0):03d}.{page_id:05d}.page",
                section=f"{place} / Sources / {source} / {page_name} / Programming / {device}",
                template="programming",
                place=place,
                device=device,
                source=source,
                page=page_name,
                change="inventory",
                details=f"PageOrder={page['PageOrder']}; HiddenPage={page['HiddenPage']}",
                source_table="PagesView",
                source_key=str(page_id),
                unresolved=mark_unresolved(device, source, page_name),
            )
        )
        page_layers = layers_by_page.get(page_id, [])
        host_layer_name: dict[int, str] = {}
        for layer in page_layers:
            layer_name = catalog.layer_name(int(layer["SharedLayerId"]))
            rows.append(
                InventoryRow(
                    sort_key=f"90.{rti:03d}.{int(page['PageOrder'] or 0):03d}.{page_id:05d}.L{int(layer['LayerId']):05d}",
                    section=f"{place} / Sources / {source} / {page_name} / Programming / {device} / {layer_name}",
                    template="programming",
                    place=place,
                    device=device,
                    source=source,
                    page=page_name,
                    layer=layer_name,
                    details=_layer_property_details(catalog, layer),
                    source_table="Layers",
                    source_key=str(layer["LayerId"]),
                    unresolved=mark_unresolved(device, source, page_name, layer_name),
                )
            )
            for button in buttons_by_shared.get(int(layer["SharedLayerId"] or 0), []):
                if int(button["ButtonId"]) in viewport_hosts:
                    host_layer_name[int(button["ButtonId"])] = layer_name
                rows.append(
                    _button_row(
                        catalog,
                        place,
                        device,
                        source,
                        page_name,
                        layer_name,
                        "",
                        button,
                        rti,
                        int(page["PageOrder"] or 0),
                        page_id,
                        int(layer["LayerId"]),
                        macros_by_tag,
                        variables_by_tag,
                        page_links_by_tag,
                        viewport_hosts,
                        macros_with_steps,
                    )
                )

        for host_id, parent_layer in host_layer_name.items():
            for child in children_by_host.get(host_id, []):
                viewport_layer = catalog.layer_name(int(child["SharedLayerId"]))
                rows.append(
                    InventoryRow(
                        sort_key=f"90.{rti:03d}.{int(page['PageOrder'] or 0):03d}.{page_id:05d}.V{host_id:05d}.L{int(child['LayerId']):05d}",
                        section=f"{place} / Sources / {source} / {page_name} / Programming / {device} / {parent_layer} / {viewport_layer}",
                        template="programming",
                        place=place,
                        device=device,
                        source=source,
                        page=page_name,
                        layer=parent_layer,
                        viewport_layer=viewport_layer,
                        details=_layer_property_details(catalog, child),
                        source_table="Layers",
                        # Viewport children have a single global LayerId (PageId null) but are
                        # shown under every host page — page_id keeps identities distinct when
                        # many pages share the same name (Sung: 23× Home / Room Floorplan).
                        source_key=f"{page_id}.{int(child['LayerId'])}",
                        unresolved=mark_unresolved(
                            device, source, page_name, parent_layer, viewport_layer
                        ),
                    )
                )
                for button in buttons_by_shared.get(int(child["SharedLayerId"] or 0), []):
                    rows.append(
                        _button_row(
                            catalog,
                            place,
                            device,
                            source,
                            page_name,
                            parent_layer,
                            viewport_layer,
                            button,
                            rti,
                            int(page["PageOrder"] or 0),
                            page_id,
                            int(child["LayerId"]),
                            macros_by_tag,
                            variables_by_tag,
                            page_links_by_tag,
                            viewport_hosts,
                            macros_with_steps,
                        )
                    )
    return rows


def _button_row(
    catalog: NameCatalog,
    place: str,
    device: str,
    source: str,
    page_name: str,
    layer: str,
    viewport_layer: str,
    button: sqlite3.Row,
    rti: int,
    page_order: int,
    page_id: int,
    layer_id: int,
    macros_by_tag: dict[int, list[sqlite3.Row]],
    variables_by_tag: dict[int, list[sqlite3.Row]],
    page_links_by_tag: dict[tuple[int, int], sqlite3.Row],
    viewport_hosts: set[int],
    macros_with_steps: set[int],
) -> InventoryRow:
    button_id = int(button["ButtonId"])
    tag_id = positive_tag_id(button["ButtonTagId"])
    row_tag = str(_optional(button, "ButtonTagName") or "").strip()
    tag_name = usable_name(row_tag or (catalog.tag_name(tag_id) if tag_id else ""))
    width = int(button["ButtonWidth"] or 0)
    height = int(button["ButtonHeight"] or 0)
    style = int(button["ButtonStyle"]) if button["ButtonStyle"] is not None else None
    text = display_button_text(
        style=style,
        text=button["Text"],
        sysvar_label=catalog.sysvar_label,
    )
    frame = int(button["FrameNumber"]) if button["FrameNumber"] is not None else None
    shared_id = int(button["SharedLayerId"] or 0)
    is_keypad = shared_id in catalog.keypad_layer_ids

    # ID11: button macro / variable / page-link binds require a tag. Untagged
    # GlobalMacroId is a default stamp (Animo Macro 57 / 1790 Macro 856), not
    # button programming — even when that system macro has steps.
    raw_macro = 0
    if tag_id:
        raw_macro = int(_optional(button, "GlobalMacroId") or 0) or int(
            _optional(button, "DeviceMacroId") or 0
        )
    # 0-step GlobalMacroId targets are still not a real bind (1790 Macro 856).
    explicit_macro = raw_macro if raw_macro in macros_with_steps else 0
    tag_macros = macros_by_tag.get(tag_id, []) if tag_id else []
    has_macro = bool(explicit_macro or tag_macros)
    tag_variables = variables_by_tag.get(tag_id, []) if tag_id else []
    has_variable = bool(tag_variables)
    if tag_id:
        has_variable = bool(
            tag_variables
            or _optional(button, "GlobalVariableId")
            or _optional(button, "DeviceVariableId")
        )
    device_id = int(_optional(button, "DeviceId") or 0)
    page_link = None
    if tag_id:
        page_link = page_links_by_tag.get((device_id, tag_id))
        if page_link is None:
            page_link = page_links_by_tag.get((0, tag_id))
    has_page_link = bool(page_link)
    if tag_id:
        has_page_link = bool(
            _optional(button, "PageLinkId") or _optional(button, "LinkPageId") or page_link
        )

    empty = empty_tag_type(tag_id > 0, tag_name, text, has_macro, has_variable)
    button_type = empty or classify_button_type(
        width=width,
        height=height,
        tag_name=tag_name,
        text=text,
        button_style=style,
        has_macro=has_macro,
        has_variable=has_variable,
        has_page_link=has_page_link,
        is_keypad_layer=is_keypad,
        frame_number=frame,
    )
    if button_id in viewport_hosts and button_type == "Screen Button":
        button_type = "Screen Button"

    is_rtsp = style == RTSP_VIDEO_STYLE
    has_bitmap = has_button_bitmap_or_icon(
        up_bitmap_id=_optional(button, "UpBitmapId"),
        down_bitmap_id=_optional(button, "DownBitmapId"),
        icon_bitmap_id=_optional(button, "IconBitmapId"),
    )
    identity = button_identity(
        tag_name=tag_name,
        text=text,
        button_type=button_type,
        has_bitmap_or_icon=has_bitmap,
        is_rtsp=is_rtsp,
    )
    macro_scope = ""
    if explicit_macro:
        macro_scope = format_macro_scope(catalog, explicit_macro)
    elif tag_macros:
        first = tag_macros[0]
        macro_scope = encode_scope_from_ids(
            catalog,
            int(first["RoomId"] or 0),
            int(first["DeviceId"] if first["DeviceId"] is not None else -1),
        )

    variable_scope = ""
    if tag_variables:
        first_var = tag_variables[0]
        variable_scope = encode_scope_from_ids(
            catalog,
            int(first_var["RoomId"] or 0),
            int(first_var["DeviceId"] if first_var["DeviceId"] is not None else -1),
        )

    page_link_value = ""
    if page_link is not None:
        link_name, link_unresolved = mapped_or_unresolved(LINK_TYPE_NAMES, int(page_link["LinkType"] or 0), "LinkType")
        raw_page_id = page_link["PageId"]
        target = catalog.page_name(int(raw_page_id)) if raw_page_id is not None and int(raw_page_id) > 0 else ""
        page_link_value = target or link_name
        _ = link_unresolved
    elif tag_id and _optional(button, "LinkPageId"):
        raw_link = int(button["LinkPageId"])
        page_link_value = catalog.page_name(raw_link) if raw_link > 0 else ""

    details_parts = [
        f"ButtonId={button_id}",
        f"text={text}" if text and text != tag_name else "",
        f"style={style}",
        f"frame={frame}",
        *_layout_detail_tokens(button, catalog.controller_orientation(rti)),
        *_appearance_detail_tokens(button),
        f"macro={catalog.macro_tag(explicit_macro)}" if explicit_macro else "",
        "viewportHost" if button_id in viewport_hosts else "",
    ]
    details = "; ".join(part for part in details_parts if part)
    return InventoryRow(
        sort_key=f"90.{rti:03d}.{page_order:03d}.{page_id:05d}.L{layer_id:05d}.B{button_id:05d}.{viewport_layer or 'page'}",
        section=f"{place} / Sources / {source} / {page_name} / Programming / {device}",
        template="programming",
        place=place,
        device=device,
        source=source,
        page=page_name,
        layer=layer,
        viewport_layer=viewport_layer,
        type=button_type,
        identity=identity,
        macro_scope=macro_scope,
        variable_scope=variable_scope,
        page_link=page_link_value,
        details=details,
        source_table="RTIDeviceButtonData",
        source_key=f"{page_id}.{layer_id}.{button_id}",
        unresolved=mark_unresolved(device, source, page_name, layer, identity),
    )


def _visibility_label(catalog: NameCatalog, raw: object) -> str:
    """ID11 Visible field: XML name when known, else @token (same as Text Variable)."""
    text = str(raw or "").strip()
    if not text:
        return ""
    return catalog.sysvar_label(text) or text


def _layer_property_details(catalog: NameCatalog, layer: sqlite3.Row) -> str:
    """Layer Properties dialog tokens (page layers and viewport layers)."""
    parts: list[str] = []
    source_id = layer["SourceId"]
    if source_id is not None:
        parts.append(f"Source={catalog.source_name(int(source_id))}")
    room_id = layer["RoomId"]
    if room_id is not None:
        parts.append(f"Room={catalog.room_name(int(room_id))}")
    parts.append(f"Visible={_visibility_label(catalog, layer['VisibilityVariable'])}")
    parts.append(f"Locked={'yes' if int(layer['IsLocked'] or 0) else 'no'}")
    shared = int(layer["SharedLayerId"] or 0) in catalog.shared_layer_ids
    parts.append(f"Shared={'yes' if shared else 'no'}")
    parts.append(f"LayerOrder={layer['LayerOrder']}")
    return "; ".join(parts)


def _optional(row: sqlite3.Row, column: str) -> object:
    try:
        return row[column]
    except (IndexError, KeyError):
        return None


_PORTRAIT_RECT = ("ButtonLeft", "ButtonTop", "ButtonWidth", "ButtonHeight")
_LANDSCAPE_RECT = ("ButtonLeftAlt", "ButtonTopAlt", "ButtonWidthAlt", "ButtonHeightAlt")


def _layout_detail_tokens(button: sqlite3.Row, support: str) -> list[str]:
    """Portrait/landscape rects. Prefix orientation only when the device has both."""
    rects: list[tuple[str, tuple[str, str, str, str]]] = []
    if support in {"portrait", "both"}:
        rects.append(("portrait", _PORTRAIT_RECT))
    if support in {"landscape", "both"}:
        rects.append(("landscape", _LANDSCAPE_RECT))
    if not rects:
        rects.append(("portrait", _PORTRAIT_RECT))
    prefix = len(rects) > 1
    tokens: list[str] = []
    for name, (left_col, top_col, width_col, height_col) in rects:
        label = f"{name} " if prefix else ""
        tokens.append(f"{label}left={_int_optional(button, left_col)}")
        tokens.append(f"{label}top={_int_optional(button, top_col)}")
        width = _int_optional(button, width_col)
        height = _int_optional(button, height_col)
        tokens.append(f"{label}size={width}x{height}")
    return tokens


def _int_optional(row: sqlite3.Row, column: str) -> int:
    try:
        return int(_optional(row, column) or 0)
    except (TypeError, ValueError):
        return 0


def _color_hex(value: object) -> str:
    try:
        return f"#{int(value or 0) & 0xFFFFFF:06X}"
    except (TypeError, ValueError):
        return "#000000"


def _appearance_detail_tokens(button: sqlite3.Row) -> list[str]:
    return [
        f"fill={_color_hex(_optional(button, 'FillColorDefault'))}",
        f"fill (pressed)={_color_hex(_optional(button, 'FillColorActive'))}",
        f"line={_color_hex(_optional(button, 'LineColorDefault'))}",
        f"line (pressed)={_color_hex(_optional(button, 'LineColorActive'))}",
        f"line thickness={_int_optional(button, 'LineThickness')}",
    ]
