from __future__ import annotations

import sqlite3

from sentinel_lite.extract.helpers import mark_unresolved, system_row
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.button_identity import positive_tag_id
from sentinel_lite.resolve.catalog import NameCatalog
from sentinel_lite.resolve.tag_scope import scope_category


def extract_macro_and_variable_lists(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    for row in connection.execute(
        "select MacroId, RoomId, DeviceId, ButtonTagId, SystemMacroId, OutputType from Macros"
    ):
        # Untagged Macros are activity / room-event / source-power hook bodies — not Macro List.
        if positive_tag_id(row["ButtonTagId"]) <= 0:
            continue
        rows.append(_list_row(catalog, "Macro List", row, "Macros", int(row["MacroId"])))
    for row in connection.execute(
        "select VariableId, RoomId, DeviceId, ButtonTagId from Variables"
    ):
        if positive_tag_id(row["ButtonTagId"]) <= 0:
            continue
        rows.append(_variable_row(catalog, row))
    return rows


def _owner_place_object(catalog: NameCatalog, room_id: int, device_id: int) -> tuple[str, str, str]:
    category = scope_category(room_id, device_id)
    if category == "Global":
        return ("Global", "", "01.01")
    if category == "Room":
        return (catalog.room_name(room_id), "", f"20.{int(room_id):03d}.01")
    if category == "Source":
        place = catalog.room_name(catalog.device_room_by_id.get(device_id, room_id))
        return (place, catalog.source_name(device_id), f"20.{int(catalog.device_room_by_id.get(device_id, 0)):03d}.50")
    place = catalog.room_name(room_id) if room_id else "Global"
    controller = catalog.device_name(device_id)
    return (place, controller, f"20.{int(room_id):03d}.40")


def _list_section(place: str, object_name: str, pane: str, sort_prefix: str) -> str:
    if object_name and ".50." in f"{sort_prefix}.":
        return f"{place} / Sources / {object_name} / {pane}"
    if object_name and ".40." in f"{sort_prefix}.":
        return f"{place} / Controllers / {object_name} / {pane}"
    return " / ".join(part for part in (place, object_name, pane) if part)


def _list_row(
    catalog: NameCatalog,
    pane: str,
    row: sqlite3.Row,
    table: str,
    key: int,
) -> InventoryRow:
    room_id = int(row["RoomId"] or 0)
    device_id = int(row["DeviceId"] if row["DeviceId"] is not None else -1)
    place, object_name, sort_prefix = _owner_place_object(catalog, room_id, device_id)
    tag = catalog.tag_name(positive_tag_id(row["ButtonTagId"]))
    section = _list_section(place, object_name, pane, sort_prefix)
    return system_row(
        sort_key=f"{sort_prefix}.macro.{key:06d}",
        section=section,
        place=place,
        object_name=object_name,
        pane=pane,
        item=tag,
        details="",
        source_table=table,
        source_key=str(key),
        unresolved=mark_unresolved(tag, place, object_name),
    )


def _variable_row(catalog: NameCatalog, row: sqlite3.Row) -> InventoryRow:
    room_id = int(row["RoomId"] or 0)
    device_id = int(row["DeviceId"] if row["DeviceId"] is not None else -1)
    place, object_name, sort_prefix = _owner_place_object(catalog, room_id, device_id)
    tag = catalog.tag_name(positive_tag_id(row["ButtonTagId"]))
    section = _list_section(place, object_name, "Variable List", sort_prefix)
    return system_row(
        sort_key=f"{sort_prefix}.variable.{int(row['VariableId']):06d}",
        section=section,
        place=place,
        object_name=object_name,
        pane="Variable List",
        item=tag,
        details="",
        source_table="Variables",
        source_key=str(row["VariableId"]),
        unresolved=mark_unresolved(tag, place, object_name),
    )
