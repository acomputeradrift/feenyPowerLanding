"""Summarize untagged / hook macro bodies in ID11 words for changelog details."""

from __future__ import annotations

import sqlite3

from sentinel_lite.apex_db import table_exists
from sentinel_lite.resolve.catalog import NameCatalog

# Proven MacroSteps.Type values only (plan / continuity). Unknown stays Type n.
_STEP_TYPE_NAMES: dict[int, str] = {
    1: "Command",
    8: "Page Link",
    14: "Call Macro",
    15: "Flag",
    17: "Comment",
    22: "System Variable Test",
    24: "Select Room",
    26: "Select Activity",
    27: "Room Off",
    28: "Source Return",
    29: "Show Lists/Menus",
}


def macro_body_summary(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    macro_id: object,
) -> str:
    """Human steps for a Macros row. Empty macro → (empty). Missing id → unresolved."""
    try:
        mid = int(macro_id or 0)
    except (TypeError, ValueError):
        return ""
    if mid <= 0:
        return ""
    exists = connection.execute("select 1 from Macros where MacroId = ?", (mid,)).fetchone()
    if exists is None:
        return f"unresolved MacroId {mid}"
    steps = connection.execute(
        """
        select MacroStepId, Type, StepIndex
        from MacroSteps
        where MacroId = ?
        order by StepIndex, MacroStepId
        """,
        (mid,),
    ).fetchall()
    if not steps:
        return "(empty)"
    bits = [_step_summary(connection, catalog, step) for step in steps]
    return "; ".join(bit for bit in bits if bit)


def _step_summary(connection: sqlite3.Connection, catalog: NameCatalog, step: sqlite3.Row) -> str:
    step_id = int(step["MacroStepId"])
    step_type = int(step["Type"] or 0)
    if step_type == 8:
        return _page_link_summary(connection, catalog, step_id)
    if step_type == 1:
        return _command_summary(connection, catalog, step_id)
    if step_type == 17:
        return _comment_summary(connection, step_id)
    if step_type == 24:
        return _select_room_summary(connection, catalog, step_id)
    if step_type == 26:
        return _select_activity_summary(connection, catalog, step_id)
    if step_type == 14:
        return _call_macro_summary(connection, catalog, step_id)
    if step_type == 22:
        return _variable_test_summary(connection, catalog, step_id)
    # Flag / Room Off / Show Lists/Menus / Source Return: presence-only until maps lock.
    return _STEP_TYPE_NAMES.get(step_type, f"Type {step_type}")


def _detail_value(text: str) -> str:
    """Keep details `;`-split stable (no raw semicolons inside a token value)."""
    return text.replace(";", ",").replace("\n", " ").strip()


def _named_token(label: str, value: str) -> str:
    cleaned = _detail_value(value)
    return f"{label}={cleaned}" if cleaned else label


def _page_link_summary(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    step_id: int,
) -> str:
    # key=value so details diffs print `Page Link: A → B` (not presence arrows).
    if not table_exists(connection, "MacroPageLink"):
        return "Page Link"
    row = connection.execute(
        "select Device, Page from MacroPageLink where MacroStepId = ?",
        (step_id,),
    ).fetchone()
    if row is None:
        return "Page Link"
    device_id = int(row["Device"] or 0)
    page = int(row["Page"] or 0)
    device = catalog.source_name(device_id) if device_id else ""
    if page == 0 and device:
        # Page 0 = that source's landing page (same pattern as Apple TV / Classic Nintendo).
        return _named_token("Page Link", device)
    if page > 0:
        page_name = catalog.page_name(page)
        target = page_name or f"PageId {page}"
        return _named_token("Page Link", target)
    return _named_token("Page Link", device) if device else "Page Link"


def _command_summary(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    step_id: int,
) -> str:
    if not table_exists(connection, "MacroDeviceCommand"):
        return "Command"
    row = connection.execute(
        "select * from MacroDeviceCommand where MacroStepId = ?",
        (step_id,),
    ).fetchone()
    if row is None:
        return "Command"
    device = catalog.device_name(int(row["DeviceId"])) if row["DeviceId"] is not None else ""
    function = str(row["Function"] or "").strip()
    if function.startswith("SetCommand:"):
        function = function[len("SetCommand:") :]
    params = [
        str(row[key]).strip()
        for key in ("Parameter1", "Parameter2", "Parameter3", "Parameter4")
        if row[key] is not None and str(row[key]).strip()
    ]
    command = function
    if params:
        command = f"{function}={' '.join(params)}" if function else " ".join(params)
    if device and command:
        body = f"{device}: {command}"
    else:
        body = command or device
    return _named_token("Command", body) if body else "Command"


def _comment_summary(connection: sqlite3.Connection, step_id: int) -> str:
    if not table_exists(connection, "MacroComment"):
        return "Comment"
    row = connection.execute(
        "select CommentText from MacroComment where MacroStepId = ?",
        (step_id,),
    ).fetchone()
    if row is None:
        return "Comment"
    return _named_token("Comment", str(row["CommentText"] or ""))


def _select_room_summary(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    step_id: int,
) -> str:
    if not table_exists(connection, "MacroSelectRoom"):
        return "Select Room"
    row = connection.execute(
        "select SelectRoomId from MacroSelectRoom where MacroStepId = ?",
        (step_id,),
    ).fetchone()
    if row is None or row["SelectRoomId"] is None:
        return "Select Room"
    return _named_token("Select Room", catalog.room_name(int(row["SelectRoomId"])))


def _select_activity_summary(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    step_id: int,
) -> str:
    if not table_exists(connection, "MacroSelectSource"):
        return "Select Activity"
    row = connection.execute(
        "select SelectSourceId from MacroSelectSource where MacroStepId = ?",
        (step_id,),
    ).fetchone()
    if row is None or row["SelectSourceId"] is None:
        return "Select Activity"
    return _named_token(
        "Select Activity",
        catalog.activity_name(int(row["SelectSourceId"])),
    )


def _call_macro_summary(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    step_id: int,
) -> str:
    if not table_exists(connection, "MacroFunctionCall"):
        return "Call Macro"
    row = connection.execute(
        "select CommandTagId from MacroFunctionCall where MacroStepId = ?",
        (step_id,),
    ).fetchone()
    if row is None or row["CommandTagId"] is None:
        return "Call Macro"
    tag_id = int(row["CommandTagId"])
    if tag_id <= 0:
        return "Call Macro"
    return _named_token("Call Macro", catalog.tag_name(tag_id))


def _variable_test_summary(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    step_id: int,
) -> str:
    if not table_exists(connection, "MacroVariableTest"):
        return "System Variable Test"
    row = connection.execute(
        "select VariableDeviceId, Variable from MacroVariableTest where MacroStepId = ?",
        (step_id,),
    ).fetchone()
    if row is None:
        return "System Variable Test"
    raw = str(row["Variable"] or "").strip()
    label = catalog.sysvar_label(raw) if raw else ""
    token = label or raw
    device_id = row["VariableDeviceId"]
    device = catalog.device_name(int(device_id)) if device_id is not None else ""
    if device and token:
        body = f"{device}: {token}"
    else:
        body = token or device
    return _named_token("System Variable Test", body) if body else "System Variable Test"
