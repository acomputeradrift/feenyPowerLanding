from __future__ import annotations

import sqlite3

from sentinel_lite.extract.helpers import mark_unresolved, system_row
from sentinel_lite.extract.macro_body import macro_body_summary
from sentinel_lite.locked_maps import (
    ROOM_EVENT_DESELECTED_NAMES,
    ROOM_EVENT_SELECTED_NAMES,
)
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.catalog import NameCatalog


def extract_activities_and_room_events(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    for row in connection.execute(
        """
        select ActivitiesId, RoomId, DeviceId, SelectedMacroId, DeselectedMacroId,
               Checked, ActivityOrder, PagelinkMacroId
        from Activities
        order by RoomId, ActivityOrder, ActivitiesId
        """
    ):
        room_id = int(row["RoomId"] or 0)
        device_id = int(row["DeviceId"] or 0)
        place = catalog.room_name(room_id)
        activity = catalog.activity_name(device_id)
        # Identity is room + source device — ActivitiesId is recycled across files.
        owner_key = f"{room_id}.{device_id}"
        activity_key = f"20.{room_id:03d}.20.{int(row['ActivityOrder'] or 0):03d}.{int(row['ActivitiesId'])}"
        rows.append(
            system_row(
                sort_key=f"{activity_key}.identity",
                section=f"{place} / Activities / {activity}",
                place=place,
                object_name=activity,
                details=f"Checked={row['Checked']}; ActivityOrder={row['ActivityOrder']}",
                source_table="Activities",
                source_key=owner_key,
                unresolved=mark_unresolved(place, activity),
            )
        )
        if row["SelectedMacroId"]:
            body = macro_body_summary(connection, catalog, row["SelectedMacroId"])
            rows.append(
                system_row(
                    sort_key=f"{activity_key}.selected",
                    section=f"{place} / Activities / {activity} / Selection Events",
                    place=place,
                    object_name=activity,
                    pane="Selection Events",
                    item="Activity Selected",
                    details=body,
                    source_table="Activities",
                    source_key=f"{owner_key}.SelectedMacroId",
                    unresolved=mark_unresolved(place, activity, body),
                )
            )
        if row["DeselectedMacroId"]:
            body = macro_body_summary(connection, catalog, row["DeselectedMacroId"])
            rows.append(
                system_row(
                    sort_key=f"{activity_key}.deselected",
                    section=f"{place} / Activities / {activity} / Deselection Events",
                    place=place,
                    object_name=activity,
                    pane="Deselection Events",
                    item="Activity Deselected",
                    details=body,
                    source_table="Activities",
                    source_key=f"{owner_key}.DeselectedMacroId",
                    unresolved=mark_unresolved(place, activity, body),
                )
            )
        if row["PagelinkMacroId"]:
            body = macro_body_summary(connection, catalog, row["PagelinkMacroId"])
            rows.append(
                system_row(
                    sort_key=f"{activity_key}.pagelink",
                    section=f"{place} / Activities / {activity} / Selection Events",
                    place=place,
                    object_name=activity,
                    pane="Selection Events",
                    item="Activity Ready",
                    details=body,
                    source_table="Activities",
                    source_key=f"{owner_key}.PagelinkMacroId",
                    unresolved=mark_unresolved(place, activity, body),
                )
            )
    for row in connection.execute(
        "select RoomEventsId, EventType, RoomId, SelectedMacroId, DeselectedMacroId from RoomEvents"
    ):
        room_id = int(row["RoomId"] or 0)
        place = catalog.room_name(room_id)
        event_type = int(row["EventType"] or 0)
        event_id = int(row["RoomEventsId"])
        selected_name = ROOM_EVENT_SELECTED_NAMES.get(event_type)
        deselected_name = ROOM_EVENT_DESELECTED_NAMES.get(event_type)
        if row["SelectedMacroId"]:
            body = macro_body_summary(connection, catalog, row["SelectedMacroId"])
            if selected_name is None:
                item = f"EventType {event_type}"
                unresolved = f"unresolved RoomEvents.EventType {event_type}"
            else:
                item = selected_name
                unresolved = mark_unresolved(place, body)
            rows.append(
                system_row(
                    sort_key=f"20.{room_id:03d}.21.{event_type:02d}.{event_id}.selected",
                    section=f"{place} / Room Events",
                    place=place,
                    pane="Room Events",
                    item=item,
                    details=body,
                    source_table="RoomEvents",
                    source_key=f"{room_id}.{event_type}.SelectedMacroId",
                    unresolved=unresolved,
                )
            )
        if row["DeselectedMacroId"]:
            body = macro_body_summary(connection, catalog, row["DeselectedMacroId"])
            if deselected_name is None:
                item = f"EventType {event_type} Deselected"
                unresolved = f"unresolved RoomEvents.EventType {event_type}"
            else:
                item = deselected_name
                unresolved = mark_unresolved(place, body)
            rows.append(
                system_row(
                    sort_key=f"20.{room_id:03d}.21.{event_type:02d}.{event_id}.deselected",
                    section=f"{place} / Room Events",
                    place=place,
                    pane="Room Events",
                    item=item,
                    details=body,
                    source_table="RoomEvents",
                    source_key=f"{room_id}.{event_type}.DeselectedMacroId",
                    unresolved=unresolved,
                )
            )
        if (
            not row["SelectedMacroId"]
            and not row["DeselectedMacroId"]
            and selected_name is None
            and deselected_name is None
        ):
            # Keep empty unknown slots visible so unresolved integers stay in inventory.
            rows.append(
                system_row(
                    sort_key=f"20.{room_id:03d}.21.{event_type:02d}.{event_id}",
                    section=f"{place} / Room Events",
                    place=place,
                    pane="Room Events",
                    item=f"EventType {event_type}",
                    details="",
                    source_table="RoomEvents",
                    source_key=f"{room_id}.{event_type}",
                    unresolved=f"unresolved RoomEvents.EventType {event_type}",
                )
            )
    for row in connection.execute("select SourceEventsId, SourceId, OnMacroId, OffMacroId from SourceEvents"):
        source_id = int(row["SourceId"] or 0)
        room_id = catalog.device_room_by_id.get(source_id, 0)
        place = catalog.room_name(room_id) if room_id else "Global"
        source = catalog.source_name(source_id)
        on_macro = macro_body_summary(connection, catalog, row["OnMacroId"]) if row["OnMacroId"] else ""
        off_macro = macro_body_summary(connection, catalog, row["OffMacroId"]) if row["OffMacroId"] else ""
        details = "; ".join(
            part
            for part in (
                f"On={on_macro}" if on_macro else "",
                f"Off={off_macro}" if off_macro else "",
            )
            if part
        )
        rows.append(
            system_row(
                sort_key=f"20.{room_id:03d}.50.{source_id:04d}.power",
                section=f"{place} / Sources / {source} / Usage Events / Source Power Events",
                place=place,
                object_name=source,
                pane="Usage Events / Source Power Events",
                details=details,
                source_table="SourceEvents",
                source_key=str(source_id),
                unresolved=mark_unresolved(source, on_macro, off_macro),
            )
        )
    return rows
