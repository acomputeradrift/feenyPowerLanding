from __future__ import annotations

import sqlite3

from sentinel_lite.extract.helpers import system_row
from sentinel_lite.locked_maps import flag_label
from sentinel_lite.records import InventoryRow


def extract_flag_names(
    connection: sqlite3.Connection,
    *,
    rti_address: int,
    place: str,
    object_name: str,
    sort_base: str,
) -> list[InventoryRow]:
    pane = "Properties / Flag Names"
    rows: list[InventoryRow] = []
    for row in connection.execute(
        "select VariableId, VariableIndex, VariableName from VariableNames"
        " where RTIAddress = ? order by VariableIndex",
        (rti_address,),
    ):
        item = flag_label(int(row["VariableIndex"]))
        sort_suffix = f"{rti_address}.{int(row['VariableIndex']):04d}"
        rows.append(
            system_row(
                sort_key=f"{sort_base}.{pane}.{sort_suffix}",
                section=f"{place} / {object_name} / {pane}",
                place=place,
                object_name=object_name,
                pane=pane,
                item=item,
                details=str(row["VariableName"] or ""),
                source_table="VariableNames",
                source_key=str(row["VariableId"]),
            )
        )
    return rows
