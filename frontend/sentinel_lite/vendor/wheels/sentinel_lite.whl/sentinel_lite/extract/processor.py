from __future__ import annotations

import sqlite3

from sentinel_lite.apex_db import table_exists
from sentinel_lite.extract.flags import extract_flag_names
from sentinel_lite.extract.helpers import mark_unresolved, system_row
from sentinel_lite.locked_maps import (
    ESC_2_DEVICE_TYPE,
    EXPANSION_DEVICE_TYPE_NAMES,
    PROCESSOR_EVENT_TYPE_NAMES,
    TIMEZONE_NAMES,
    expansion_rs232_port_group,
    is_esc2_rs232_port_key,
    mapped_or_unresolved,
    port_label_group,
)
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.catalog import NameCatalog
from sentinel_lite.resolve.ipv4 import dotted_ipv4_from_signed_int
from sentinel_lite.secrets import redact_value


def extract_processor(connection: sqlite3.Connection, catalog: NameCatalog) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    processor = connection.execute("select * from RTIDeviceData where RTIAddress = 0").fetchone()
    if processor is None:
        return rows
    rows.extend(_property_fields(processor, catalog))
    rows.extend(_settings(connection))
    rows.extend(_events(connection, catalog))
    rows.extend(_expansion_devices(connection))
    rows.extend(_port_labels(connection))
    rows.extend(
        extract_flag_names(
            connection,
            rti_address=0,
            place="Global",
            object_name="Processor",
            sort_base="01.03",
        )
    )
    rows.extend(_relay_mode(connection))
    return rows


def _field(
    pane: str,
    item: str,
    details: object,
    source_table: str,
    source_key: str,
    unresolved: str = "",
    sort_suffix: str = "",
) -> InventoryRow:
    return system_row(
        sort_key=f"01.03.{pane}.{sort_suffix or item}",
        section=f"Global / Processor / {pane}",
        place="Global",
        object_name="Processor",
        pane=pane,
        item=item,
        details=str(redact_value(item, details)),
        source_table=source_table,
        source_key=source_key,
        unresolved=unresolved,
    )


def _property_fields(processor: sqlite3.Row, catalog: NameCatalog) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    rows.append(_field("Properties / General", "Save State On Download", processor["SaveStateOnDownload"], "RTIDeviceData", "0.SaveStateOnDownload"))
    rows.append(_field("Properties / General", "Enable IR Input", processor["EnableIrInput"], "RTIDeviceData", "0.EnableIrInput"))
    rows.append(_field("Properties / Wired Network", "Use DHCP", processor["NetUseDhcp"], "RTIDeviceData", "0.NetUseDhcp"))
    for column, label in (
        ("IpaddressAdapter0", "IP Address"),
        ("NetmaskAdapter0", "Subnet Mask"),
        ("GatewayAdapter0", "Gateway"),
        ("Dns1Adapter0", "DNS 1"),
        ("Dns2Adapter0", "DNS 2"),
    ):
        rows.append(
            _field(
                "Properties / Wired Network",
                label,
                dotted_ipv4_from_signed_int(processor[column]),
                "RTIDeviceData",
                f"0.{column}",
            )
        )
    rows.append(_field("Properties / Wired Network", "Allow Programming", processor["NetAllowProgramming"], "RTIDeviceData", "0.NetAllowProgramming"))
    timezone, tz_unresolved = mapped_or_unresolved(TIMEZONE_NAMES, processor["TimeZone"], "TimeZone")
    rows.append(_field("Properties / Clock", "Use Clock Defaults", processor["UseClockDefaults"], "RTIDeviceData", "0.UseClockDefaults"))
    rows.append(_field("Properties / Clock", "Time Zone", timezone, "RTIDeviceData", "0.TimeZone", tz_unresolved if tz_unresolved else ""))
    rows.append(_field("Properties / Location", "Use Location Defaults", processor["UseLocationDefaults"], "RTIDeviceData", "0.UseLocationDefaults"))
    rows.append(_field("Properties / Location", "Location Name", processor["LocationName"], "RTIDeviceData", "0.LocationName"))
    _ = catalog
    return rows


def _settings(connection: sqlite3.Connection) -> list[InventoryRow]:
    if not table_exists(connection, "RTiQConfig"):
        return []
    row = connection.execute("select Name, LocalEnabled, Enabled, EnableDebug, APIKey from RTiQConfig").fetchone()
    if row is None:
        return []
    return [
        _field("Settings", "System Name", row["Name"], "RTiQConfig", "Name"),
        _field("Settings", "Onboard Diagnostics", row["LocalEnabled"], "RTiQConfig", "LocalEnabled"),
        _field("Settings", "Cloud Monitoring", row["Enabled"], "RTiQConfig", "Enabled"),
        _field("Settings", "Cloud Debug", row["EnableDebug"], "RTiQConfig", "EnableDebug"),
        _field("Settings", "API Key", redact_value("APIKey", row["APIKey"]), "RTiQConfig", "APIKey"),
    ]


def _events(connection: sqlite3.Connection, catalog: NameCatalog) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    for row in connection.execute(
        "select EventId, EventType, Description, Enabled, DriverId, MacroId from Events"
    ):
        event_type, unresolved_type = mapped_or_unresolved(
            PROCESSOR_EVENT_TYPE_NAMES, int(row["EventType"] or 0), "EventType"
        )
        if event_type == "Driver":
            continue
        driver = catalog.device_name(int(row["DriverId"])) if row["DriverId"] else ""
        macro = catalog.macro_tag(int(row["MacroId"])) if row["MacroId"] else ""
        object_name = "Processor"
        section = "Global / Processor / Events"
        place = "Global"
        rows.append(
            system_row(
                sort_key=f"01.03.Events.{int(row['EventId']):04d}",
                section=section,
                place=place,
                object_name=object_name,
                pane="Events",
                item=event_type,
                details=f"Enabled={row['Enabled']}; Description={row['Description']}; macro={macro}",
                source_table="Events",
                source_key=str(row["EventId"]),
                unresolved=mark_unresolved(event_type if unresolved_type else "", driver, macro),
            )
        )
    return rows


def _expansion_devices(connection: sqlite3.Connection) -> list[InventoryRow]:
    if not table_exists(connection, "ExpansionDevices"):
        return []
    count = connection.execute("select count(*) from ExpansionDevices").fetchone()[0]
    if int(count) == 0:
        return [
            _field(
                "Expansion Devices",
                "(none)",
                "skip — no rows",
                "ExpansionDevices",
                "empty",
            )
        ]
    from sentinel_lite.locked_maps import EXPANSION_DEVICE_TYPE_NAMES

    rows: list[InventoryRow] = []
    for row in connection.execute("select * from ExpansionDevices"):
        model, unresolved = mapped_or_unresolved(
            EXPANSION_DEVICE_TYPE_NAMES, int(row["DeviceType"] or 0), "Unknown DeviceType"
        )
        name = str(row["Name"] or "").strip()
        rows.append(
            _field(
                "Expansion Devices",
                f"{model} / {name}",
                f"ExpanderId={row['ExpanderId']}; RTIAddress={row['RTIAddress']}",
                "ExpansionDevices",
                str(row["ExpanderId"]),
                "unresolved DeviceType" if unresolved else "",
            )
        )
    return rows


def _port_labels(connection: sqlite3.Connection) -> list[InventoryRow]:
    esc2_group = _esc2_rs232_port_group(connection)
    rows: list[InventoryRow] = []
    for row in connection.execute(
        "select PortLabelId, RTIAddress, LabelKey, LabelName from PortLabels where RTIAddress = 0"
    ):
        key = int(row["LabelKey"])
        if is_esc2_rs232_port_key(key):
            group = esc2_group
            unresolved = "" if esc2_group else "unresolved ESC-2 port group"
            if not group:
                group = port_label_group(key)
        else:
            group = port_label_group(key)
            unresolved = "unresolved" if group.startswith("unresolved") else ""
        rows.append(
            _field(
                "Properties / Port Names",
                f"{group} / {row['LabelName']}",
                f"LabelKey={key}",
                "PortLabels",
                str(row["PortLabelId"]),
                unresolved,
                sort_suffix=str(key),
            )
        )
    return rows


def _esc2_rs232_port_group(connection: sqlite3.Connection) -> str:
    """ID11 Port Names expander entry: `[ESC-2] {ExpansionDevices.Name} (RS-232)`."""
    if not table_exists(connection, "ExpansionDevices"):
        return ""
    row = connection.execute(
        """
        select Name, DeviceType from ExpansionDevices
        where DeviceType = ?
        order by ExpansionDeviceId
        limit 1
        """,
        (ESC_2_DEVICE_TYPE,),
    ).fetchone()
    if row is None:
        return ""
    model = EXPANSION_DEVICE_TYPE_NAMES.get(int(row["DeviceType"] or 0), "ESC-2")
    return expansion_rs232_port_group(model, str(row["Name"] or ""))


def _relay_mode(connection: sqlite3.Connection) -> list[InventoryRow]:
    if not table_exists(connection, "RelayModeMap"):
        return []
    row = connection.execute("select * from RelayModeMap").fetchone()
    if row is None:
        return []
    details = ", ".join(f"{key}={row[key]}" for key in row.keys())
    return [_field("Properties / Relay Mode", "RelayModeMap", details, "RelayModeMap", "0")]
