"""Apex extractors. Each module reads tables and emits InventoryRow values."""
