from __future__ import annotations

from sentinel_lite.records import InventoryRow


def system_row(
    *,
    sort_key: str,
    section: str,
    place: str,
    object_name: str = "",
    pane: str = "",
    item: str = "",
    details: str = "",
    source_table: str,
    source_key: str,
    unresolved: str = "",
) -> InventoryRow:
    return InventoryRow(
        sort_key=sort_key,
        section=section,
        template="system",
        place=place,
        object=object_name,
        pane=pane,
        item=item,
        details=details,
        source_table=source_table,
        source_key=source_key,
        unresolved=unresolved,
    )


def mark_unresolved(*parts: str) -> str:
    flags = [part for part in parts if part.startswith("unresolved")]
    return "; ".join(flags)
