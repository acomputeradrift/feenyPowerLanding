from __future__ import annotations

import sqlite3

from sentinel_lite.extract.helpers import mark_unresolved, system_row
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.catalog import NameCatalog
from sentinel_lite.resolve.driver_xml import (
    expand_driver_placeholders,
    is_debug_setting,
    parse_config_items,
    parse_system_events,
    resolve_setting_value,
)
from sentinel_lite.secrets import redact_value


def extract_drivers(connection: sqlite3.Connection, catalog: NameCatalog) -> list[InventoryRow]:
    config_by_driver: dict[int, dict[str, str]] = {}
    for row in connection.execute("select DriverDeviceId, Name, Value from DriverConfig"):
        config_by_driver.setdefault(int(row["DriverDeviceId"]), {})[str(row["Name"] or "")] = str(row["Value"] or "")

    rows: list[InventoryRow] = []
    for driver in connection.execute(
        "select DriverDeviceId, DeviceId, ConfigItems, SystemEvents from DriverData"
    ):
        device_id = int(driver["DeviceId"] or 0)
        driver_device_id = int(driver["DriverDeviceId"])
        name = catalog.device_name(device_id)
        room_id = catalog.device_room_by_id.get(device_id, 0)
        place = "Global"
        sort_base = f"01.05.{device_id:04d}"
        values = config_by_driver.get(driver_device_id, {})
        for setting in parse_config_items(driver["ConfigItems"]):
            if is_debug_setting(setting):
                continue
            raw = values.get(setting.variable, "")
            resolved = resolve_setting_value(setting, raw)
            details = str(redact_value(setting.setting_name, resolved))
            rows.append(
                system_row(
                    sort_key=f"{sort_base}.prop.{setting.variable}",
                    section=f"{place} / Drivers / {name} / Properties / {setting.category}",
                    place=place,
                    object_name=name,
                    pane=f"Properties / {setting.category}",
                    item=setting.setting_name or setting.variable,
                    details=details,
                    source_table="DriverConfig",
                    source_key=f"{driver_device_id}.{setting.variable}",
                    unresolved=mark_unresolved(name),
                )
            )
        event_defs = {event.tag: event for event in parse_system_events(driver["SystemEvents"])}
        for event_row in connection.execute(
            "select EventId, DriverExtraString, MacroId, Enabled from Events where DriverId = ?",
            (device_id,),
        ):
            tag = str(event_row["DriverExtraString"] or "").strip()
            definition = event_defs.get(tag)
            raw_name = definition.name if definition and definition.name else (tag or "unresolved event")
            item = expand_driver_placeholders(raw_name, values)
            macro = catalog.macro_tag(int(event_row["MacroId"])) if event_row["MacroId"] else ""
            rows.append(
                system_row(
                    sort_key=f"{sort_base}.event.{int(event_row['EventId']):04d}",
                    section=f"{place} / Drivers / {name} / Events",
                    place=place,
                    object_name=name,
                    pane="Events",
                    item=item,
                    details=f"tag={tag}; Enabled={event_row['Enabled']}; macro={macro}",
                    source_table="Events",
                    source_key=str(event_row["EventId"]),
                    unresolved=mark_unresolved(name, item if item.startswith("unresolved") else "", macro),
                )
            )
    return rows
