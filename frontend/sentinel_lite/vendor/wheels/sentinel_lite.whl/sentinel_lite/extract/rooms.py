from __future__ import annotations

import sqlite3

from sentinel_lite.extract.helpers import mark_unresolved, system_row
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.catalog import NameCatalog


def extract_rooms(connection: sqlite3.Connection, catalog: NameCatalog) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    for row in connection.execute("select RoomId, Name, HomePageId, RoomOrder from Rooms order by RoomOrder, RoomId"):
        room_id = int(row["RoomId"])
        name = catalog.room_name(room_id)
        home_id = int(row["HomePageId"] or 0)
        home = catalog.page_name(home_id) if home_id else ""
        if room_id == 0:
            place = "Global"
            sort_key = "01.00.00"
            section = "Global"
        else:
            place = name
            room_order = int(row["RoomOrder"] or 0)
            sort_key = f"20.{room_order:03d}.{room_id:03d}.00"
            section = name
        # Identity is the place name (add / remove / rename). Do not repeat it as item
        # (that produced `Global / Global`).
        rows.append(
            system_row(
                sort_key=sort_key,
                section=section,
                place=place,
                details=f"RoomOrder={row['RoomOrder']}",
                source_table="Rooms",
                source_key=str(room_id),
                unresolved=mark_unresolved(name),
            )
        )
        rows.append(
            system_row(
                sort_key=f"{sort_key}.homepage",
                section=f"{section} / Home Page",
                place=place,
                item="Home Page",
                details=home,
                source_table="Rooms",
                source_key=f"{room_id}.HomePage",
                unresolved=mark_unresolved(home),
            )
        )
    return rows
