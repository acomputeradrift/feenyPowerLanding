from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import replace
from pathlib import Path
from typing import Protocol

import sqlite3

from sentinel_lite.apex_db import open_apex
from sentinel_lite.compare.identity import identity_key
from sentinel_lite.extract.activities import extract_activities_and_room_events
from sentinel_lite.extract.controllers import extract_controllers
from sentinel_lite.extract.drivers import extract_drivers
from sentinel_lite.extract.lists import extract_macro_and_variable_lists
from sentinel_lite.extract.processor import extract_processor
from sentinel_lite.extract.programming import extract_programming
from sentinel_lite.extract.rooms import extract_rooms
from sentinel_lite.extract.sources import extract_sources
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.catalog import NameCatalog, load_name_catalog


class Extractor(Protocol):
    def __call__(
        self, connection: sqlite3.Connection, catalog: NameCatalog
    ) -> Sequence[InventoryRow]: ...


EXTRACTORS: tuple[Extractor, ...] = (
    extract_rooms,
    extract_processor,
    extract_controllers,
    extract_drivers,
    extract_macro_and_variable_lists,
    extract_sources,
    extract_activities_and_room_events,
    extract_programming,
)


class DuplicateIdentityError(ValueError):
    """Two extracted rows hashed to the same compare identity."""


def load_inventory(apex_path: Path) -> list[InventoryRow]:
    rows, _catalog = load_inventory_bundle(apex_path)
    return rows


def load_inventory_bundle(
    apex_path: Path,
    *,
    on_progress: Callable[[str], None] | None = None,
) -> tuple[list[InventoryRow], NameCatalog]:
    with open_apex(Path(apex_path)) as connection:
        catalog = load_name_catalog(connection)
        return collect_inventory(connection, catalog, on_progress=on_progress), catalog


def collect_inventory(
    connection: sqlite3.Connection,
    catalog: NameCatalog,
    *,
    on_progress: Callable[[str], None] | None = None,
) -> list[InventoryRow]:
    rows: list[InventoryRow] = []
    for extract in EXTRACTORS:
        if on_progress is not None:
            on_progress(extractor_label(extract))
        rows.extend(extract(connection, catalog))
    assigned = _assign_identity_keys(rows)
    assigned.sort(key=lambda row: (row.sort_key, row.section, row.item, row.identity))
    return assigned


def extractor_label(extract: Extractor) -> str:
    """Progress wording for one extractor, derived so a new one needs no table."""
    name = getattr(extract, "__name__", "").removeprefix("extract_").replace("_", " ")
    return name[:1].upper() + name[1:] if name else "Inventory"


def _assign_identity_keys(rows: Sequence[InventoryRow]) -> list[InventoryRow]:
    assigned: list[InventoryRow] = []
    seen: dict[str, InventoryRow] = {}
    for row in rows:
        key = identity_key(row)
        tagged = replace(row, identity_key=key)
        prior = seen.get(key)
        if prior is not None:
            raise DuplicateIdentityError(
                f"Duplicate identity_key {key!r} for {tagged.source_table}/{tagged.source_key}"
            )
        seen[key] = tagged
        assigned.append(tagged)
    return assigned
