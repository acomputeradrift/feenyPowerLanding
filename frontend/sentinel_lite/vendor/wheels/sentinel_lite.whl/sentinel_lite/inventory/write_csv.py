from __future__ import annotations

import csv
from pathlib import Path

from sentinel_lite.records import InventoryRow

CSV_COLUMNS: tuple[str, ...] = (
    "sort_key",
    "template",
    "place",
    "object",
    "pane",
    "item",
    "device",
    "source",
    "page",
    "layer",
    "viewport_layer",
    "type",
    "identity",
    "macro_scope",
    "variable_scope",
    "page_link",
    "change",
    "details",
    "source_table",
    "source_key",
    "identity_key",
    "unresolved",
)


def write_inventory_csv(path: Path, rows: list[InventoryRow]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(CSV_COLUMNS), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row.as_csv_dict())
