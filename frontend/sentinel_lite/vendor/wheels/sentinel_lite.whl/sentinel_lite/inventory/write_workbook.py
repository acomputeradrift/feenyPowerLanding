from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from sentinel_lite.records import InventoryRow

SYSTEM_COLUMNS: tuple[str, ...] = (
    "sort_key",
    "place",
    "object",
    "pane",
    "item",
    "change",
    "details",
    "source_table",
    "source_key",
    "unresolved",
)

PROGRAMMING_COLUMNS: tuple[str, ...] = (
    "sort_key",
    "device",
    "source",
    "page",
    "layer",
    "viewport_layer",
    "type",
    "identity",
    "macro_scope",
    "variable_scope",
    "page_link",
    "change",
    "details",
    "source_table",
    "source_key",
    "unresolved",
)

_HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
_HEADER_FONT = Font(color="FFFFFF", bold=True)
_HEADER_ALIGN = Alignment(vertical="center", wrap_text=True)


def write_inventory_workbook(path: Path, rows: list[InventoryRow]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    system_sheet = workbook.active
    system_sheet.title = "System"
    _write_sheet(
        system_sheet,
        SYSTEM_COLUMNS,
        [row for row in rows if row.template == "system"],
    )
    programming_sheet = workbook.create_sheet("Programming")
    _write_sheet(
        programming_sheet,
        PROGRAMMING_COLUMNS,
        [row for row in rows if row.template == "programming"],
    )
    workbook.save(path)


def _write_sheet(sheet: Worksheet, columns: tuple[str, ...], rows: list[InventoryRow]) -> None:
    sheet.append(list(columns))
    header = sheet[1]
    for cell in header:
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = _HEADER_ALIGN
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:{get_column_letter(len(columns))}1"
    sheet.row_dimensions[1].height = 22

    for row in rows:
        payload = row.as_csv_dict()
        sheet.append([payload.get(column, "") for column in columns])

    last_row = max(sheet.max_row, 1)
    sheet.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{last_row}"
    _fit_column_widths(sheet, columns)


def _fit_column_widths(sheet: Worksheet, columns: tuple[str, ...]) -> None:
    sample_limit = min(sheet.max_row, 200)
    for index, column_name in enumerate(columns, start=1):
        letter = get_column_letter(index)
        longest = len(column_name)
        for row_number in range(2, sample_limit + 1):
            value = sheet.cell(row_number, index).value
            if value is None:
                continue
            longest = max(longest, min(len(str(value)), 60))
        width = 18 if column_name == "details" else min(max(longest + 2, 12), 48)
        if column_name == "details":
            width = 56
        sheet.column_dimensions[letter].width = width
