"""Inventory snapshot — not the final changelog writer."""
