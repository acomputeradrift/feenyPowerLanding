from __future__ import annotations

import xml.etree.ElementTree as ElementTree
from dataclasses import dataclass


@dataclass(frozen=True)
class DriverSetting:
    category: str
    setting_name: str
    variable: str
    setting_type: str
    choices: dict[str, str]


@dataclass(frozen=True)
class DriverEventDefinition:
    tag: str
    name: str


def parse_config_items(xml_text: str | None) -> list[DriverSetting]:
    if not xml_text:
        return []
    try:
        root = ElementTree.fromstring(xml_text)
    except ElementTree.ParseError:
        return []
    settings: list[DriverSetting] = []
    for category in root.findall(".//category"):
        category_name = str(category.attrib.get("name") or "").strip()
        for setting in category.findall("setting"):
            choices = {
                str(choice.attrib.get("value") or ""): str(choice.attrib.get("name") or "").strip()
                for choice in setting.findall("choice")
            }
            settings.append(
                DriverSetting(
                    category=category_name,
                    setting_name=str(setting.attrib.get("name") or "").strip(),
                    variable=str(setting.attrib.get("variable") or "").strip(),
                    setting_type=str(setting.attrib.get("type") or "").strip(),
                    choices=choices,
                )
            )
    return settings


def parse_system_events(xml_text: str | None) -> list[DriverEventDefinition]:
    if not xml_text:
        return []
    try:
        root = ElementTree.fromstring(xml_text)
    except ElementTree.ParseError:
        return []
    events: list[DriverEventDefinition] = []
    for event in root.findall(".//event"):
        events.append(
            DriverEventDefinition(
                tag=str(event.attrib.get("tag") or "").strip(),
                name=str(event.attrib.get("name") or "").strip(),
            )
        )
    return events


def resolve_setting_value(setting: DriverSetting, raw_value: str) -> str:
    if raw_value in setting.choices and setting.choices[raw_value]:
        return setting.choices[raw_value]
    return raw_value


def expand_driver_placeholders(template: str, config_values: dict[str, str]) -> str:
    """Sentinel-proven %%VariableName%% expansion from DriverConfig."""
    resolved = template
    for name, value in config_values.items():
        resolved = resolved.replace(f"%%{name}%%", value)
    return resolved


def is_debug_setting(setting: DriverSetting) -> bool:
    haystack = f"{setting.category} {setting.setting_name} {setting.variable}".lower()
    return "debug" in haystack
