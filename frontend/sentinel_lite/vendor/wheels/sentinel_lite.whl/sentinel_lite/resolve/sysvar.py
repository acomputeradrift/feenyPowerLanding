"""SYSVARREF → human label (Oracle LoadSysVarRefMap rules)."""

from __future__ import annotations

import re
import sqlite3
import xml.etree.ElementTree as ElementTree
from collections.abc import Mapping

from sentinel_lite.resolve.driver_xml import expand_driver_placeholders

# {GUID} optional #segment then @token (format / sample after ! stripped for lookup).
_REF_RE = re.compile(
    r"(?P<guid>\{[0-9A-Fa-f-]{36}\})(?:#(?P<device>[^@]*))?@(?P<token>[^!]*)",
    re.IGNORECASE,
)


def parse_sysvar_ref(raw: object) -> tuple[str, str]:
    """Return (DriverId GUID with braces, sysvar token). Empty strings when missing."""
    guid, _device_id, token = parse_sysvar_parts(raw)
    return guid, token


def parse_sysvar_parts(raw: object) -> tuple[str, int | None, str]:
    """Return (GUID, #DeviceId or None, sysvar token)."""
    text = str(raw or "").strip()
    if not text:
        return "", None, ""
    match = _REF_RE.search(text)
    if not match:
        if "@" in text:
            return "", None, text.rsplit("@", 1)[-1].split("!", 1)[0].strip()
        return "", None, ""
    guid = str(match.group("guid") or "").strip()
    token = str(match.group("token") or "").strip()
    device_raw = str(match.group("device") or "").strip()
    device_id: int | None = None
    if device_raw.isdigit():
        device_id = int(device_raw)
    return guid, device_id, token


def parse_system_variable_names(xml_text: str | None) -> dict[str, str]:
    """sysvar attribute → XML name (first wins). Same source as Oracle VariableName."""
    if not xml_text:
        return {}
    try:
        root = ElementTree.fromstring(xml_text)
    except ElementTree.ParseError:
        return {}
    names: dict[str, str] = {}
    for el in root.iter("variable"):
        sysvar = str(el.attrib.get("sysvar") or "").strip()
        name = str(el.attrib.get("name") or "").strip()
        if sysvar and name and sysvar not in names:
            names[sysvar] = name
    return names


def load_sysvar_names(connection: sqlite3.Connection) -> dict[tuple[str, str], str]:
    """(DriverId.lower(), sysvar token) → XML name. Keyed by GUID like Oracle."""
    out: dict[tuple[str, str], str] = {}
    try:
        rows = connection.execute("select DriverId, SystemVariables from DriverData")
    except sqlite3.Error:
        return out
    for row in rows:
        driver_id = str(row["DriverId"] or "").strip()
        if not driver_id:
            continue
        guid_key = driver_id.lower()
        for sysvar, name in parse_system_variable_names(row["SystemVariables"]).items():
            key = (guid_key, sysvar)
            if key not in out:
                out[key] = name
    return out


def load_driver_configs(connection: sqlite3.Connection) -> dict[int, dict[str, str]]:
    """Devices.DeviceId → DriverConfig Name/Value (via DriverData.DriverDeviceId)."""
    out: dict[int, dict[str, str]] = {}
    try:
        rows = connection.execute(
            """
            select dd.DeviceId, dc.Name, dc.Value
            from DriverData dd
            join DriverConfig dc on dc.DriverDeviceId = dd.DriverDeviceId
            """
        )
    except sqlite3.Error:
        return out
    for row in rows:
        device_id = int(row["DeviceId"] or 0)
        name = str(row["Name"] or "").strip()
        if not name:
            continue
        bucket = out.setdefault(device_id, {})
        if name not in bucket:
            bucket[name] = str(row["Value"] or "")
    return out


def lookup_sysvar_name(
    names: Mapping[tuple[str, str], str],
    *,
    guid: str,
    token: str,
) -> str:
    """XML name for guid+token, or empty. Tries token with trailing % stripped."""
    if not guid or not token:
        return ""
    guid_key = guid.lower()
    candidates = [token]
    stripped = token.rstrip("%")
    if stripped and stripped != token:
        candidates.append(stripped)
    for candidate in candidates:
        hit = names.get((guid_key, candidate), "")
        if hit:
            return hit
    return ""


def sysvar_display_name(
    raw: object,
    names: Mapping[tuple[str, str], str] | None = None,
    configs: Mapping[int, Mapping[str, str]] | None = None,
    devices_by_guid: Mapping[str, tuple[int, ...]] | None = None,
) -> str:
    """XML name (%% expanded from that instance's DriverConfig), else @token."""
    guid, device_id, token = parse_sysvar_parts(raw)
    if names and guid and token:
        label = lookup_sysvar_name(names, guid=guid, token=token)
        if label:
            if "%%" in label and configs is not None:
                conf = _config_for_ref(
                    configs,
                    device_id=device_id,
                    guid=guid,
                    devices_by_guid=devices_by_guid,
                )
                if conf:
                    label = expand_driver_placeholders(label, dict(conf))
            return label
    if token:
        return token.rstrip("%") or token
    text = str(raw or "").strip()
    return text


def _config_for_ref(
    configs: Mapping[int, Mapping[str, str]],
    *,
    device_id: int | None,
    guid: str,
    devices_by_guid: Mapping[str, tuple[int, ...]] | None,
) -> Mapping[str, str] | None:
    """Prefer #DeviceId config; if missing and the GUID has one instance, use that.

    Covers stale #segments (Sung Nest still says #119; live device is #215).
    Never guess among multiple instances (WattBox / Lutron).
    """
    if device_id is not None:
        conf = configs.get(device_id)
        if conf:
            return conf
    if not devices_by_guid or not guid:
        return None
    instances = devices_by_guid.get(guid.lower(), ())
    if len(instances) == 1:
        return configs.get(instances[0])
    return None