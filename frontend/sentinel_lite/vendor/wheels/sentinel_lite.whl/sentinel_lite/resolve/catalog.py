from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field

from sentinel_lite.apex_db import table_exists
from sentinel_lite.locked_maps import ORIENTATION_SUPPORT
from sentinel_lite.resolve.button_identity import positive_tag_id
from sentinel_lite.resolve.sysvar import (
    load_driver_configs,
    load_sysvar_names,
    sysvar_display_name,
)


def display_or_name(display_name: object, raw_name: object) -> str:
    """Prefer DisplayName (activity / UI), then Name."""
    display = str(display_name or "").strip()
    if display:
        return display
    return str(raw_name or "").strip()


def name_or_display(raw_name: object, display_name: object) -> str:
    """Prefer Name (source / system), then DisplayName."""
    name = str(raw_name or "").strip()
    if name:
        return name
    return str(display_name or "").strip()


@dataclass
class NameCatalog:
    system_name: str = ""
    room_by_id: dict[int, str] = field(default_factory=dict)
    room_order_by_id: dict[int, int] = field(default_factory=dict)
    device_by_id: dict[int, str] = field(default_factory=dict)
    device_source_name_by_id: dict[int, str] = field(default_factory=dict)
    device_activity_name_by_id: dict[int, str] = field(default_factory=dict)
    device_room_by_id: dict[int, int] = field(default_factory=dict)
    device_display_order_by_id: dict[int, int] = field(default_factory=dict)
    driver_device_ids: set[int] = field(default_factory=set)
    controller_by_rti: dict[int, str] = field(default_factory=dict)
    controller_device_id_by_rti: dict[int, int] = field(default_factory=dict)
    controller_orientation_by_rti: dict[int, str] = field(default_factory=dict)
    page_name_by_id: dict[int, str] = field(default_factory=dict)
    page_name_by_name_id: dict[int, str] = field(default_factory=dict)
    tag_by_id: dict[int, str] = field(default_factory=dict)
    layer_by_shared_id: dict[int, str] = field(default_factory=dict)
    keypad_layer_ids: set[int] = field(default_factory=set)
    shared_layer_ids: set[int] = field(default_factory=set)
    macro_tag_by_id: dict[int, str] = field(default_factory=dict)
    macro_tag_by_system_id: dict[int, str] = field(default_factory=dict)
    macro_scope_by_id: dict[int, tuple[int, int]] = field(default_factory=dict)
    # (DriverId.lower(), sysvar) → DriverData.SystemVariables XML name (Oracle).
    sysvar_name_by_key: dict[tuple[str, str], str] = field(default_factory=dict)
    # Devices.DeviceId → DriverConfig Name/Value (%% expansion; instance-specific).
    driver_config_by_device_id: dict[int, dict[str, str]] = field(default_factory=dict)
    # DriverId.lower() → Devices.DeviceId instances (sole-instance %% fallback).
    devices_by_driver_guid: dict[str, tuple[int, ...]] = field(default_factory=dict)

    def room_name(self, room_id: int | None) -> str:
        if room_id is None:
            return ""
        if int(room_id) == 0:
            return self.room_by_id.get(0, "Global")
        return self.room_by_id.get(int(room_id), f"unresolved RoomId {room_id}")

    def device_name(self, device_id: int | None) -> str:
        """Generic device label (DisplayName preferred). Prefer source_name / activity_name when known."""
        if device_id is None:
            return ""
        return self.device_by_id.get(int(device_id), f"unresolved DeviceId {device_id}")

    def source_name(self, device_id: int | None) -> str:
        """Devices.Name (source / system). Fallback DisplayName, then device_by_id."""
        if device_id is None:
            return ""
        key = int(device_id)
        if key in self.device_source_name_by_id:
            return self.device_source_name_by_id[key]
        return self.device_by_id.get(key, f"unresolved DeviceId {device_id}")

    def activity_name(self, device_id: int | None) -> str:
        """Devices.DisplayName (activity / UI). Fallback Name, then device_by_id."""
        if device_id is None:
            return ""
        key = int(device_id)
        if key in self.device_activity_name_by_id:
            return self.device_activity_name_by_id[key]
        return self.device_by_id.get(key, f"unresolved DeviceId {device_id}")

    def controller_name(self, rti_address: int | None) -> str:
        if rti_address is None:
            return ""
        return self.controller_by_rti.get(int(rti_address), f"unresolved RTIAddress {rti_address}")

    def controller_orientation(self, rti_address: int | None) -> str:
        """portrait, landscape, or both. Unknown devices are portrait-only."""
        if rti_address is None:
            return "portrait"
        return self.controller_orientation_by_rti.get(int(rti_address), "portrait")

    def page_name(self, page_id: int | None) -> str:
        if page_id is None:
            return ""
        return self.page_name_by_id.get(int(page_id), f"unresolved PageId {page_id}")

    def tag_name(self, tag_id: int | None) -> str:
        if tag_id is None or int(tag_id) <= 0:
            return ""
        return self.tag_by_id.get(int(tag_id), f"unresolved ButtonTagId {tag_id}")

    def layer_name(self, shared_layer_id: int | None) -> str:
        if shared_layer_id is None:
            return ""
        return self.layer_by_shared_id.get(int(shared_layer_id), f"unresolved SharedLayerId {shared_layer_id}")

    def macro_tag(self, macro_id: int | None) -> str:
        if not macro_id:
            return ""
        key = int(macro_id)
        if key in self.macro_tag_by_id:
            return self.macro_tag_by_id[key]
        if key in self.macro_tag_by_system_id:
            return self.macro_tag_by_system_id[key]
        return f"unresolved MacroId {macro_id}"

    def sysvar_label(self, raw: object) -> str:
        """XML name with DriverConfig %% expand, else @token (never GUID blob)."""
        return sysvar_display_name(
            raw,
            self.sysvar_name_by_key,
            self.driver_config_by_device_id,
            self.devices_by_driver_guid,
        )


def load_name_catalog(connection: sqlite3.Connection) -> NameCatalog:
    catalog = NameCatalog()
    if table_exists(connection, "RTiQConfig"):
        row = connection.execute("select Name from RTiQConfig").fetchone()
        if row is not None:
            catalog.system_name = str(row["Name"] or "").strip()
    for row in connection.execute("select RoomId, Name, RoomOrder from Rooms"):
        room_id = int(row["RoomId"])
        catalog.room_by_id[room_id] = str(row["Name"] or "").strip() or f"Room {row['RoomId']}"
        catalog.room_order_by_id[room_id] = int(row["RoomOrder"] or 0)

    for row in connection.execute(
        "select DeviceId, DisplayName, Name, RoomId, DisplayOrder from Devices"
    ):
        device_id = int(row["DeviceId"])
        source = name_or_display(row["Name"], row["DisplayName"])
        activity = display_or_name(row["DisplayName"], row["Name"])
        catalog.device_source_name_by_id[device_id] = source
        catalog.device_activity_name_by_id[device_id] = activity
        # Generic lookups keep DisplayName-preferred (controllers / drivers / legacy).
        catalog.device_by_id[device_id] = activity or source
        catalog.device_room_by_id[device_id] = int(row["RoomId"] or 0)
        catalog.device_display_order_by_id[device_id] = int(row["DisplayOrder"] or 0)

    if table_exists(connection, "DriverData"):
        by_guid: dict[str, list[int]] = {}
        for row in connection.execute("select DeviceId, DriverId from DriverData"):
            device_id = int(row["DeviceId"] or 0)
            catalog.driver_device_ids.add(device_id)
            guid = str(row["DriverId"] or "").strip().lower()
            if guid:
                by_guid.setdefault(guid, []).append(device_id)
        catalog.devices_by_driver_guid = {
            guid: tuple(device_ids) for guid, device_ids in by_guid.items()
        }
        catalog.sysvar_name_by_key = load_sysvar_names(connection)
        if table_exists(connection, "DriverConfig"):
            catalog.driver_config_by_device_id = load_driver_configs(connection)

    for row in connection.execute(
        """
        select rd.RTIAddress, rd.DeviceId, d.DisplayName, d.Name, rd.SupportedOrientations
        from RTIDeviceData rd
        left join Devices d on d.DeviceId = rd.DeviceId
        """
    ):
        rti = int(row["RTIAddress"])
        catalog.controller_by_rti[rti] = display_or_name(row["DisplayName"], row["Name"]) or f"RTIAddress {rti}"
        catalog.controller_device_id_by_rti[rti] = int(row["DeviceId"] or 0)
        catalog.controller_orientation_by_rti[rti] = ORIENTATION_SUPPORT.get(
            int(row["SupportedOrientations"] or 0),
            "portrait",
        )

    if table_exists(connection, "PagesView"):
        for row in connection.execute("select PageId, PageName from PagesView"):
            catalog.page_name_by_id[int(row["PageId"])] = str(row["PageName"] or "").strip()
    for row in connection.execute("select PageNameId, PageName from PageNames"):
        catalog.page_name_by_name_id[int(row["PageNameId"])] = str(row["PageName"] or "").strip()

    for row in connection.execute("select ButtonTagId, ButtonTagName from ButtonTagNames"):
        catalog.tag_by_id[int(row["ButtonTagId"])] = str(row["ButtonTagName"] or "").strip()

    if table_exists(connection, "SharedLayers"):
        for row in connection.execute("select SharedLayerId, Name, IsKeypadLayer, IsShared from SharedLayers"):
            shared_id = int(row["SharedLayerId"])
            catalog.layer_by_shared_id[shared_id] = str(row["Name"] or "").strip() or f"SharedLayer {shared_id}"
            if int(row["IsKeypadLayer"] or 0) == 1:
                catalog.keypad_layer_ids.add(shared_id)
            if int(row["IsShared"] or 0) == 1:
                catalog.shared_layer_ids.add(shared_id)

    for row in connection.execute("select MacroId, SystemMacroId, RoomId, DeviceId, ButtonTagId from Macros"):
        macro_id = int(row["MacroId"])
        tag_id = positive_tag_id(row["ButtonTagId"])
        label = catalog.tag_name(tag_id) if tag_id else f"Macro {macro_id}"
        catalog.macro_tag_by_id[macro_id] = label
        system_id = int(row["SystemMacroId"] or 0)
        if system_id:
            catalog.macro_tag_by_system_id[system_id] = label
        catalog.macro_scope_by_id[macro_id] = (int(row["RoomId"] or 0), int(row["DeviceId"] if row["DeviceId"] is not None else -1))

    return catalog
