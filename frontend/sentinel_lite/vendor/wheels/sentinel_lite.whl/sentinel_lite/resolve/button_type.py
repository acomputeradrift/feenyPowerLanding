"""Button type labels from Sentinel extractor_core classification + locked frames."""

from __future__ import annotations

from sentinel_lite.locked_maps import (
    BUTTON_STYLE_TYPES,
    HARD_KEY_GESTURE_FRAME,
    HARD_KEY_PHYSICAL_FRAME,
    RTSP_VIDEO_STYLE,
)


def classify_button_type(
    *,
    width: int,
    height: int,
    tag_name: str,
    text: str,
    button_style: int | None,
    has_macro: bool,
    has_variable: bool,
    has_page_link: bool,
    is_keypad_layer: bool,
    frame_number: int | None,
) -> str:
    if is_keypad_layer and frame_number == HARD_KEY_PHYSICAL_FRAME:
        return "Slot"
    if is_keypad_layer and frame_number == HARD_KEY_GESTURE_FRAME:
        return "Gesture"
    if tag_name == "":
        if text == "" and not has_macro and not has_variable:
            return "UI Item"
        # tagged-field empty is Empty Tag only when a tag id existed; caller passes tag_name
    if width == 0 and height == 0:
        return "Hard Button"
    style_type = BUTTON_STYLE_TYPES.get(int(button_style)) if button_style is not None else None
    if button_style == RTSP_VIDEO_STYLE:
        style_type = "RTSP Video"
    if (
        text
        and not has_page_link
        and not has_macro
        and style_type is None
    ):
        return "Screen Label"
    if has_page_link and not has_macro and not has_variable:
        return "Page Link"
    return "Screen Button"


def empty_tag_type(has_tag_id: bool, tag_name: str, text: str, has_macro: bool, has_variable: bool) -> str | None:
    if has_tag_id and tag_name == "":
        return "Empty Tag"
    if (not has_tag_id) and text == "" and not has_macro and not has_variable:
        return "UI Item"
    return None
