"""Button identity labels for Programming changelog lines."""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping

from sentinel_lite.locked_maps import RTSP_VIDEO_STYLE
from sentinel_lite.resolve.sysvar import sysvar_display_name

_TEXT_TOKEN_RE = re.compile(r"\$%(TAG|VARIABLE)!(.*?)%\$", re.IGNORECASE | re.DOTALL)
_RTSP_PLACEHOLDERS = frozenset({"rtsp video"})


def positive_tag_id(raw: object) -> int:
    """ButtonTagId <= 0 means no tag (-1 is the usual empty)."""
    try:
        value = int(raw or 0)
    except (TypeError, ValueError):
        return 0
    return value if value > 0 else 0


def usable_name(value: object) -> str:
    """Blank or digits-only is not an identity."""
    text = str(value or "").strip()
    if not text or text.isdigit():
        return ""
    return text


def display_button_text(
    *,
    style: int | None,
    text: object,
    sysvar_names: Mapping[tuple[str, str], str] | None = None,
    driver_configs: Mapping[int, Mapping[str, str]] | None = None,
    sysvar_label: Callable[[object], str] | None = None,
) -> str:
    """Expand $%TAG!…%$ / $%VARIABLE!…%$. RTSP style has no display text.

    VARIABLE labels: XML name + DriverConfig %% expand when known, else @token.
    Never leave the GUID / format / sample blob.
    """
    if style == RTSP_VIDEO_STYLE:
        return ""
    raw = str(text or "")
    if not raw:
        return ""

    def replace_token(match: re.Match[str]) -> str:
        token_type = str(match.group(1) or "").strip().upper()
        token_value = str(match.group(2) or "")
        if token_type == "TAG":
            return f"<Text Tag: {token_value}>"
        if token_type == "VARIABLE":
            if sysvar_label is not None:
                label = str(sysvar_label(token_value) or "").strip()
            else:
                label = sysvar_display_name(token_value, sysvar_names, driver_configs)
            return f"<Text Variable: {label or token_value}>"
        return match.group(0)

    return _TEXT_TOKEN_RE.sub(replace_token, raw)


def has_button_bitmap_or_icon(
    *,
    up_bitmap_id: object,
    down_bitmap_id: object,
    icon_bitmap_id: object,
) -> bool:
    def present(raw: object) -> bool:
        try:
            return int(raw) != -1
        except (TypeError, ValueError):
            return False

    return present(up_bitmap_id) or present(down_bitmap_id) or present(icon_bitmap_id)


# Older name kept for call sites that mean bitmap/icon only.
def has_button_graphics(
    *,
    up_bitmap_id: object,
    down_bitmap_id: object,
    icon_bitmap_id: object,
    button_style: int | None = None,
) -> bool:
    _ = button_style
    return has_button_bitmap_or_icon(
        up_bitmap_id=up_bitmap_id,
        down_bitmap_id=down_bitmap_id,
        icon_bitmap_id=icon_bitmap_id,
    )


def button_identity(
    *,
    tag_name: str,
    text: str,
    button_type: str = "",
    has_bitmap_or_icon: bool = False,
    is_rtsp: bool = False,
    has_graphics: bool = False,
) -> str:
    """Never omit. Never Button {id}.

    Named controls: tag → display text.
    UI Item (no tag/text/real bind): RTSP Video → Graphics → Element.
    Other types without a name: RTSP Video → Graphics.
    """
    tag = usable_name(tag_name)
    if tag:
        return f"“{tag}”"
    shown = str(text or "").strip()
    if shown and shown.lower() not in _RTSP_PLACEHOLDERS:
        return shown
    bitmap = has_bitmap_or_icon or has_graphics
    if button_type == "UI Item":
        if is_rtsp:
            return "RTSP Video"
        if bitmap:
            return "Graphics"
        return "Element"
    if is_rtsp:
        return "RTSP Video"
    return "Graphics"
