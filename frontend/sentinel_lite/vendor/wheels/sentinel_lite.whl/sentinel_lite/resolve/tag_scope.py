"""ID11 Tag Editor scope labels. Category rules from Sentinel _scope; names from tables."""

from __future__ import annotations

from sentinel_lite.resolve.catalog import NameCatalog


def scope_category(room_id: int | None, device_id: int | None) -> str:
    room = 0 if room_id is None else int(room_id)
    device = -1 if device_id is None else int(device_id)
    if room == 0 and device == -1:
        return "Global"
    if room > 0 and device == -1:
        return "Room"
    if room == 0 and device >= 0:
        return "Source"
    return "Controller"


def scope_parts(
    catalog: NameCatalog, room_id: int | None, device_id: int | None
) -> tuple[str, str, str]:
    """(level, room, device) from Macros/Variables RoomId+DeviceId. Empty when unused."""
    category = scope_category(room_id, device_id)
    if category == "Global":
        return ("Global", "", "")
    if category == "Room":
        return ("Room", catalog.room_name(room_id), "")
    if category == "Source":
        source_name = catalog.source_name(device_id)
        source_room_id = catalog.device_room_by_id.get(int(device_id or 0), 0)
        return ("Source", catalog.room_name(source_room_id), source_name)
    # Controller — device is the locked controller/source DeviceId.
    return ("Controller", catalog.room_name(room_id), catalog.device_name(device_id))


def encode_scope_field(level: str, room: str = "", device: str = "") -> str:
    """Comparable macro_scope / variable_scope value (level/room/device tokens)."""
    level = str(level or "").strip()
    if not level:
        return ""
    bits = [f"level={level}"]
    room = str(room or "").strip()
    device = str(device or "").strip()
    if room:
        bits.append(f"room={room}")
    if device:
        bits.append(f"device={device}")
    return "; ".join(bits)


def encode_scope_from_ids(
    catalog: NameCatalog, room_id: int | None, device_id: int | None
) -> str:
    level, room, device = scope_parts(catalog, room_id, device_id)
    return encode_scope_field(level, room, device)


def format_id11_scope(catalog: NameCatalog, room_id: int | None, device_id: int | None) -> str:
    """Tag Editor labels: Global · Source (room > source) · Room (room); Controller under Room."""
    category = scope_category(room_id, device_id)
    if category == "Global":
        return "Global"
    room_name = catalog.room_name(room_id)
    if category == "Room":
        return f"Room ({room_name})"
    if category == "Source":
        source_name = catalog.source_name(device_id)
        source_room_id = catalog.device_room_by_id.get(int(device_id or 0), 0)
        source_room = catalog.room_name(source_room_id)
        return f"Source ({source_room} > {source_name})"
    return f"Room ({room_name}) · Controller"


def format_macro_scope(catalog: NameCatalog, macro_id: int | None) -> str:
    """Comparable Programming macro_scope field (structured level/room/device)."""
    if not macro_id:
        return ""
    room_id, device_id = catalog.macro_scope_by_id.get(int(macro_id), (None, None))
    if room_id is None:
        return encode_scope_field("unresolved", device=f"MacroId {macro_id}")
    return encode_scope_from_ids(catalog, room_id, device_id)
