"""Signed Adapter0 integers → dotted IPv4. Plan: never emit the raw int as the name."""

from __future__ import annotations


def dotted_ipv4_from_signed_int(value: int | None) -> str:
    if value is None:
        return ""
    unsigned = int(value) & 0xFFFFFFFF
    return ".".join(str((unsigned >> shift) & 0xFF) for shift in (24, 16, 8, 0))
