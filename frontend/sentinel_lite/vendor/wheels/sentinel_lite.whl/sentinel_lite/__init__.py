"""Sentinel Lite — local Apex changelog extract and resolve."""

__version__ = "0.6.1"
