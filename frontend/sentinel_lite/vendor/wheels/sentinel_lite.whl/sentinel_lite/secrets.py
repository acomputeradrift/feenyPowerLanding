"""Redact credentials. Never write secret values into inventory output."""

from __future__ import annotations

SECRET_NAME_MARKERS: tuple[str, ...] = (
    "password",
    "passwd",
    "username",
    "user name",
    "apikey",
    "api_key",
    "api key",
    "passcode",
    "privatekey",
    "private key",
    "pkcs12",
    "recoverykey",
    "networkkey",
    "encryption",
    "secret",
    "token",
    "auth",
)

REDACTED = "present (secret)"


def is_secret_field(field_name: str) -> bool:
    lowered = field_name.lower().replace("_", " ").replace("-", " ")
    compacted = lowered.replace(" ", "")
    for marker in SECRET_NAME_MARKERS:
        if marker.replace(" ", "") in compacted:
            return True
    return False


def redact_value(field_name: str, value: object) -> object:
    if is_secret_field(field_name):
        if value is None or value == "":
            return ""
        return REDACTED
    return value
