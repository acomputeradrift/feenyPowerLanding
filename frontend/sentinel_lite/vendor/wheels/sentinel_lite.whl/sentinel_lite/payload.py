"""Wire shape for a compare result.

One definition, shared by the browser adapter and the lab tooling, so the
object `web/app.js` consumes can never drift between the two callers.
Serialization only — no compare or format logic lives here.
"""

from __future__ import annotations

from sentinel_lite.compare.models import CompareResult


def result_payload(result: CompareResult) -> dict[str, object]:
    return {
        "type": "result",
        "status": "no_changes" if not result.entries else "ok",
        "previousFile": result.previous_file,
        "currentFile": result.current_file,
        "systemName": result.system_name,
        "placeOrder": list(result.place_order),
        "sourceOrder": {place: list(names) for place, names in result.source_order},
        "driverOrder": list(result.driver_order),
        "entries": [
            {
                "place": entry.place,
                "branch": entry.branch,
                "source": entry.source,
                "driver": entry.driver,
                "template": entry.template,
                "kind": entry.kind.value,
                "line": entry.line,
                "segments": [
                    {"label": label, "text": text} for label, text in entry.segments
                ],
            }
            for entry in result.entries
        ],
    }
