from __future__ import annotations

import re
from collections.abc import Sequence

from sentinel_lite.compare.models import ChangeKind, FieldDelta
from sentinel_lite.records import InventoryRow

_SYSTEM_PATH: tuple[str, ...] = ("place", "object", "pane", "item")
_PROGRAMMING_PATH: tuple[str, ...] = (
    "device",
    "source",
    "page",
    "layer",
    "viewport_layer",
    "type",
    "identity",
)
_PROGRAMMING_LABELS: dict[str, str] = {
    "device": "Device",
    "source": "Source",
    "page": "Page",
    "layer": "Page Layer",
    "viewport_layer": "Viewport Layer",
    "type": "Type",
    "identity": "Identity",
}
# Header tree inserts before object (same pattern as Drivers).
_SYSTEM_BRANCH_INSERTS: tuple[tuple[str, str, str], ...] = (
    ("/ Drivers /", "Drivers", "drivers"),
    ("/ Controllers /", "Controllers", "controllers"),
    ("/ Sources /", "Sources", "sources"),
    ("/ Activities /", "Activities", "activities"),
)
_SYSTEM_LABELS: dict[str, str] = {
    "place": "Place",
    "object": "Name",
    "pane": "Pane",
    "item": "Item",
    "drivers": "Drivers",
    "controllers": "Controllers",
    "sources": "Sources",
    "activities": "Activities",
}
_FIELD_LABELS: dict[str, str] = {
    "object": "name",
}
_SCOPE_FIELDS = frozenset({"macro_scope", "variable_scope"})
_SCOPE_BIND_LABELS: dict[str, str] = {
    "macro_scope": "Macro",
    "variable_scope": "Variable",
}
_TAG_LIST_PANES = frozenset({"Macro List", "Variable List"})
_LIST_SUBJECTS: dict[str, str] = {
    "Macro List": "Macro",
    "Variable List": "Variable",
}
# Event / activity hook panes whose details are macro-step bodies (not Macro List membership).
_MACRO_STEP_PANES = frozenset(
    {
        "Selection Events",
        "Deselection Events",
        "Room Events",
        "Usage Events / Source Power Events",
    }
)
_KIND_WORDS: dict[ChangeKind, str] = {
    ChangeKind.ADDED: "Added",
    ChangeKind.REMOVED: "Removed",
    ChangeKind.CHANGED: "Changed",
}
_POSITION_KEYS = frozenset(
    {
        "left",
        "top",
        "portrait left",
        "portrait top",
        "landscape left",
        "landscape top",
    }
)
_LAYOUT_KEYS = _POSITION_KEYS | {
    "size",
    "width",
    "height",
    "portrait size",
    "portrait width",
    "portrait height",
    "landscape size",
    "landscape width",
    "landscape height",
}
_LAYOUT_KEY_ORDER: tuple[str, ...] = (
    "portrait left",
    "portrait top",
    "portrait size",
    "portrait width",
    "portrait height",
    "landscape left",
    "landscape top",
    "landscape size",
    "landscape width",
    "landscape height",
    "left",
    "top",
    "size",
    "width",
    "height",
)
_SIZE_TOKEN = re.compile(r"^\d+x\d+$")
_BOLD_MARK = re.compile(r"\*\*(.+?)\*\*")


def format_line(
    kind: ChangeKind,
    row: InventoryRow,
    deltas: Sequence[FieldDelta] = (),
) -> str:
    """Plain changelog line. Tag names use “”. Type / identity / change are **bold** markers."""
    path = " / ".join(text for _, text in path_segments(kind, row, deltas))
    suffix = _suffix(kind, row, deltas)
    if path:
        return f"{path} : {suffix}"
    return suffix


def split_change_deltas(
    kind: ChangeKind,
    row: InventoryRow,
    deltas: Sequence[FieldDelta],
) -> tuple[tuple[FieldDelta, ...], ...]:
    """One delta group per changelog line. Tag scope binds are always their own lines."""
    if kind is not ChangeKind.CHANGED or row.template != "programming":
        return (tuple(deltas),)
    scope_by_field = {delta.field: delta for delta in deltas if delta.field in _SCOPE_FIELDS}
    other = tuple(delta for delta in deltas if delta.field not in _SCOPE_FIELDS)
    groups: list[tuple[FieldDelta, ...]] = []
    for field in ("macro_scope", "variable_scope"):
        delta = scope_by_field.get(field)
        if delta is not None:
            groups.append((delta,))
    if other:
        groups.append(other)
    return tuple(groups) if groups else ((),)


def path_segments(
    kind: ChangeKind,
    row: InventoryRow,
    deltas: Sequence[FieldDelta] = (),
) -> tuple[tuple[str, str], ...]:
    """(structure label, display text) for each path segment. Omit empty segments."""
    fields = _PROGRAMMING_PATH if row.template == "programming" else _SYSTEM_PATH
    labels = _PROGRAMMING_LABELS if row.template == "programming" else _SYSTEM_LABELS
    parts: list[tuple[str, str]] = []
    for field in fields:
        part = str(getattr(row, field) or "").strip()
        if not part:
            continue
        if row.template == "programming":
            if field == "type":
                part = _bold(part)
            elif field == "identity":
                part = _bold(part)
        elif field == "item" and row.pane in _TAG_LIST_PANES:
            part = _quote_tag(part)
        # Header tree: place → Drivers|Controllers|Sources|Activities → [name].
        if row.template == "system" and field == "object":
            section = f" / {row.section} /"
            for needle, label, key in _SYSTEM_BRANCH_INSERTS:
                if needle in section:
                    parts.append((_SYSTEM_LABELS[key], label))
                    break
        parts.append((labels[field], part))
    return tuple(parts)


def plain_line(line: str) -> str:
    """Strip display bold markers for CSV / plain export."""
    return _BOLD_MARK.sub(r"\1", line)


def _bold(text: str) -> str:
    return f"**{text}**"


def _quote_tag(name: str) -> str:
    if name.startswith("“") and name.endswith("”"):
        return name
    return f"“{name}”"


def _change_subject(row: InventoryRow) -> str:
    """What the change is about — Page / Page Layer / Button / Macro / …. Empty → bare kind."""
    if row.template == "programming":
        button_type = str(row.type or "").strip()
        identity = str(row.identity or "").strip()
        if identity.startswith("<Text Variable:"):
            return "Text Variable"
        if button_type:
            if button_type == "Screen Button":
                return "Button"
            if button_type == "Screen Label":
                return "Label"
            if identity.startswith("“") and identity.endswith("”"):
                return "Tag"
            return button_type
        if str(row.viewport_layer or "").strip():
            return "Viewport Layer"
        if str(row.layer or "").strip():
            return "Page Layer"
        if str(row.page or "").strip():
            return "Page"
        return ""
    pane = str(row.pane or "").strip()
    if pane in _LIST_SUBJECTS and str(row.item or "").strip():
        return _LIST_SUBJECTS[pane]
    if pane in _MACRO_STEP_PANES or pane.startswith("Usage Events"):
        return "Macro Steps"
    if pane.startswith("Properties"):
        return "Properties"
    if pane == "Settings" or pane.startswith("Settings"):
        return "Settings"
    # Identity rows (no pane): branch in section is the subject.
    if not pane:
        section = f" / {row.section} /"
        if "/ Sources /" in section:
            return "Source"
        if "/ Activities /" in section:
            return "Activity"
    return ""


def _kind_verb(kind: ChangeKind, row: InventoryRow) -> str:
    subject = _change_subject(row)
    word = _KIND_WORDS[kind]
    return f"{subject} {word}" if subject else word


def _suffix(kind: ChangeKind, row: InventoryRow, deltas: Sequence[FieldDelta]) -> str:
    if kind is ChangeKind.ADDED:
        return _with_row_details(_bold(_kind_verb(kind, row)), row)
    if kind is ChangeKind.REMOVED:
        return _with_row_details(_bold(_kind_verb(kind, row)), row)
    if _is_tag_scope_delta_group(deltas):
        verb, details = _tag_scope_verb_and_details(deltas[0])
        bold = _bold(verb)
        return f"{bold} ({details})" if details else bold
    empty_body = _macro_steps_empty_transition(row, deltas)
    if empty_body is not None:
        verb, details = empty_body
        bold = _bold(verb)
        return f"{bold} ({details})" if details else bold
    layout, rest = _change_bits(deltas)
    if layout and rest:
        return f"{_bold_change_with_details(layout)}; {rest}"
    if layout:
        return _bold_change_with_details(layout)
    verb = _bold(_kind_verb(ChangeKind.CHANGED, row))
    if rest:
        return f"{verb} ({rest})"
    return verb


def _is_empty_macro_body(text: object) -> bool:
    """Hook body with no steps — blank or the locked `(empty)` summary."""
    stripped = str(text or "").strip()
    return not stripped or stripped == "(empty)"


def _macro_steps_empty_transition(
    row: InventoryRow,
    deltas: Sequence[FieldDelta],
) -> tuple[str, str] | None:
    """nothing↔body → Macro Steps Added|Removed; something↔something stays Changed."""
    if _change_subject(row) != "Macro Steps":
        return None
    if len(deltas) != 1 or deltas[0].field != "details":
        return None
    old = str(deltas[0].old or "").strip()
    new = str(deltas[0].new or "").strip()
    old_empty = _is_empty_macro_body(old)
    new_empty = _is_empty_macro_body(new)
    if old_empty and not new_empty:
        return "Macro Steps Added", new
    if not old_empty and new_empty:
        return "Macro Steps Removed", old
    return None


def _is_tag_scope_delta_group(deltas: Sequence[FieldDelta]) -> bool:
    return len(deltas) == 1 and deltas[0].field in _SCOPE_FIELDS


def _tag_scope_verb_and_details(delta: FieldDelta) -> tuple[str, str]:
    """Move → Tag Scope Changed; clear/appear → Macro|Variable Added|Removed."""
    bind = _SCOPE_BIND_LABELS.get(delta.field, delta.field)
    old_raw = str(delta.old or "").strip()
    new_raw = str(delta.new or "").strip()
    old_map = _scope_field_tokens(old_raw)
    new_map = _scope_field_tokens(new_raw)

    if not old_raw and new_raw:
        return f"{bind} Added", _scope_side_details(new_map, new_raw)
    if old_raw and not new_raw:
        return f"{bind} Removed", _scope_side_details(old_map, old_raw)
    return "Tag Scope Changed", _tag_scope_move_details(bind, old_map, new_map, delta)


def _scope_side_details(parts: dict[str, str], raw: str) -> str:
    if parts:
        bits: list[str] = []
        level = parts.get("level", "")
        if level:
            bits.append(f"level: {level}")
        room = parts.get("room", "")
        if room:
            bits.append(f"room: {room}")
        device = parts.get("device", "")
        if device:
            bits.append(f"device: {device}")
        return "; ".join(bits)
    text = str(raw or "").strip()
    return text


def _tag_scope_move_details(
    bind: str,
    old_map: dict[str, str],
    new_map: dict[str, str],
    delta: FieldDelta,
) -> str:
    if not old_map and not new_map:
        before = str(delta.old or "").strip() or "—"
        after = str(delta.new or "").strip() or "—"
        return f"{bind}: {before} → {after}"
    parts: list[str] = []
    for key in ("level", "room", "device"):
        before = old_map.get(key, "")
        after = new_map.get(key, "")
        if before == after:
            if key == "level" and after:
                parts.append(f"{bind} level: {after}")
            continue
        before_text = before or "—"
        after_text = after or "—"
        if key == "level":
            parts.append(f"{bind} level: {before_text} → {after_text}")
        else:
            parts.append(f"{key}: {before_text} → {after_text}")
    return "; ".join(parts)


def _scope_field_tokens(text: str) -> dict[str, str]:
    stripped = str(text or "").strip()
    if not stripped or "level=" not in stripped:
        return {}
    tokens: dict[str, str] = {}
    for part in stripped.split(";"):
        part = part.strip()
        if "=" not in part:
            continue
        key, _, value = part.partition("=")
        key = key.strip()
        if key in {"level", "room", "device"}:
            tokens[key] = value.strip()
    return tokens


def _with_row_details(verb: str, row: InventoryRow) -> str:
    details = str(row.details or "").strip()
    if details:
        return f"{verb} ({details})"
    return verb


def _bold_change_with_details(text: str) -> str:
    """Bold the verb phrase; leave parenthetical details plain."""
    if " (" in text and text.endswith(")"):
        verb, _, detail = text.partition(" (")
        return f"{_bold(verb)} ({detail}"
    return _bold(text)


def _change_bits(deltas: Sequence[FieldDelta]) -> tuple[str, str]:
    layout = ""
    rest: list[str] = []
    for delta in deltas:
        if delta.field in _SCOPE_FIELDS:
            continue
        if delta.field == "details":
            layout_bit, other = _details_change(delta.old, delta.new)
            if layout_bit:
                layout = layout_bit
            if other:
                rest.append(other)
        else:
            rest.append(f"{_field_labels(delta.field)}: {delta.old} → {delta.new}")
    return layout, "; ".join(rest)


def _field_labels(field: str) -> str:
    return _FIELD_LABELS.get(field, field)


_PRESENCE_VALUE = "present"
# Bare details tokens that mean “this step/flag exists” (not free-text values).
_PRESENCE_LABELS = frozenset(
    {
        "Command",
        "Page Link",
        "Call Macro",
        "Flag",
        "Comment",
        "System Variable Test",
        "Select Room",
        "Select Activity",
        "Room Off",
        "Source Return",
        "Show Lists/Menus",
        "viewportHost",
    }
)


def _details_change(old: str, new: str) -> tuple[str, str]:
    old_map = _details_tokens(old)
    new_map = _details_tokens(new)
    if not old_map and not new_map:
        return "", f"{old} → {new}" if old != new else ""
    layout = _layout_text(old_map, new_map)
    bits: list[str] = []
    for key in dict.fromkeys([*old_map, *new_map]):
        if key in _LAYOUT_KEYS:
            continue
        before = old_map.get(key, "")
        after = new_map.get(key, "")
        bit = _details_token_bit(key, before, after)
        if bit:
            bits.append(bit)
    if not layout and not bits:
        return "", f"{old} → {new}" if old != new else ""
    return layout, "; ".join(bits)


def _details_token_bit(key: str, before: str, after: str) -> str:
    """Empty ↔ value → Added/Removed; value ↔ value → arrow. Never print ``present``."""
    if before == after:
        return ""
    if not before and after:
        if after == _PRESENCE_VALUE:
            return f"{key} Added"
        return f"{key} Added: {after}"
    if before and not after:
        if before == _PRESENCE_VALUE:
            return f"{key} Removed"
        return f"{key} Removed: {before}"
    return f"{key}: {before} → {after}"


def _layout_text(old_map: dict[str, str], new_map: dict[str, str]) -> str:
    position_parts: list[str] = []
    size_parts: list[str] = []
    moved_px = 0
    ordered = [key for key in _LAYOUT_KEY_ORDER if key in old_map or key in new_map]
    extra = [
        key
        for key in dict.fromkeys([*old_map, *new_map])
        if key in _LAYOUT_KEYS and key not in ordered
    ]
    for key in [*ordered, *extra]:
        before = old_map.get(key, "")
        after = new_map.get(key, "")
        if before == after:
            continue
        phrase = _layout_phrase(key, before, after)
        if key in _POSITION_KEYS:
            position_parts.append(phrase)
            moved_px += _px_delta(before, after)
        else:
            size_parts.append(phrase)
    if not position_parts and not size_parts:
        return ""
    if position_parts:
        if moved_px <= 1:
            prefix = "moved 1 px"
        elif moved_px <= 12:
            prefix = "moved a few px"
        else:
            prefix = f"moved {moved_px} px"
        return f"{prefix} ({'; '.join(position_parts + size_parts)})"
    return f"resized ({'; '.join(size_parts)})"


def _layout_phrase(key: str, old: str, new: str) -> str:
    if key == "size" or key.endswith(" size"):
        prefix = key[: -len("size")].strip()
        arrow = f"{old} → {new}"
        return f"{prefix} {arrow}".strip() if prefix else arrow
    return f"{key} {old} → {new}"


def _px_delta(old: str, new: str) -> int:
    try:
        return abs(int(new) - int(old))
    except (TypeError, ValueError):
        return 0


def _details_tokens(text: str) -> dict[str, str]:
    stripped = text.strip()
    if not stripped:
        return {}
    if ";" not in stripped and "=" not in stripped:
        if _SIZE_TOKEN.match(stripped):
            return {"size": stripped}
        # Lone Comment / Show Lists/Menus / … — not free-text like System Name.
        if stripped in _PRESENCE_LABELS or stripped.startswith("Type "):
            return {stripped: _PRESENCE_VALUE}
        return {}
    tokens: dict[str, str] = {}
    for part in stripped.split(";"):
        part = part.strip()
        if not part:
            continue
        if _SIZE_TOKEN.match(part):
            tokens["size"] = part
        elif "=" in part:
            key, _, value = part.partition("=")
            tokens[key.strip()] = value.strip()
        else:
            tokens[part] = _PRESENCE_VALUE
    return tokens
