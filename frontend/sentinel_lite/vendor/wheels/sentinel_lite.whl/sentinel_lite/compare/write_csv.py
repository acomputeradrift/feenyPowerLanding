from __future__ import annotations

import csv
from pathlib import Path

from sentinel_lite.compare.format import plain_line
from sentinel_lite.compare.models import CompareResult

CSV_COLUMNS: tuple[str, ...] = (
    "previousFile",
    "currentFile",
    "place",
    "branch",
    "source",
    "kind",
    "line",
)


def write_changelog_csv(path: Path, result: CompareResult) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(CSV_COLUMNS))
        writer.writeheader()
        for entry in result.entries:
            writer.writerow(
                {
                    "previousFile": result.previous_file,
                    "currentFile": result.current_file,
                    "place": entry.place,
                    "branch": entry.branch,
                    "source": entry.source,
                    "kind": entry.kind.value,
                    "line": plain_line(entry.line),
                }
            )
