"""Filter-tree order matching ID11: RoomOrder / DisplayOrder."""

from __future__ import annotations

from collections.abc import Sequence

from sentinel_lite.compare.models import ChangelogEntry
from sentinel_lite.resolve.catalog import NameCatalog

_FALLBACK = 10**9


def merge_catalogs(*catalogs: NameCatalog) -> NameCatalog:
    """Prefer later catalogs for names/orders (current file last)."""
    merged = NameCatalog()
    for catalog in catalogs:
        if catalog.system_name:
            merged.system_name = catalog.system_name
        merged.room_by_id.update(catalog.room_by_id)
        merged.room_order_by_id.update(catalog.room_order_by_id)
        merged.device_by_id.update(catalog.device_by_id)
        merged.device_source_name_by_id.update(catalog.device_source_name_by_id)
        merged.device_activity_name_by_id.update(catalog.device_activity_name_by_id)
        merged.device_room_by_id.update(catalog.device_room_by_id)
        merged.device_display_order_by_id.update(catalog.device_display_order_by_id)
        merged.driver_device_ids.update(catalog.driver_device_ids)
        merged.sysvar_name_by_key.update(catalog.sysvar_name_by_key)
        for device_id, conf in catalog.driver_config_by_device_id.items():
            merged.driver_config_by_device_id.setdefault(device_id, {}).update(conf)
        for guid, device_ids in catalog.devices_by_driver_guid.items():
            prior = merged.devices_by_driver_guid.get(guid, ())
            merged.devices_by_driver_guid[guid] = tuple(
                dict.fromkeys((*prior, *device_ids))
            )
    return merged


def place_order(entries: Sequence[ChangelogEntry], catalog: NameCatalog) -> tuple[str, ...]:
    present = {entry.place for entry in entries if entry.place}
    ordered: list[str] = []
    if "Global" in present:
        ordered.append("Global")
    rooms = [
        (catalog.room_order_by_id.get(room_id, room_id), room_id, name)
        for room_id, name in catalog.room_by_id.items()
        if room_id != 0 and name in present
    ]
    rooms.sort()
    ordered.extend(name for _, _, name in rooms)
    for place in sorted(present):
        if place not in ordered:
            ordered.append(place)
    return tuple(ordered)


def source_order(
    entries: Sequence[ChangelogEntry],
    catalog: NameCatalog,
) -> tuple[tuple[str, tuple[str, ...]], ...]:
    by_place: dict[str, set[str]] = {}
    for entry in entries:
        if entry.branch != "sources" or not entry.source:
            continue
        by_place.setdefault(entry.place, set()).add(entry.source)
    out: list[tuple[str, tuple[str, ...]]] = []
    for place in place_order(entries, catalog):
        names = by_place.get(place)
        if not names:
            continue
        out.append((place, tuple(_order_device_names(names, catalog, place=place))))
    return tuple(out)


def driver_order(entries: Sequence[ChangelogEntry], catalog: NameCatalog) -> tuple[str, ...]:
    names = {entry.driver for entry in entries if entry.branch == "drivers" and entry.driver}
    if not names:
        return ()
    return tuple(_order_device_names(names, catalog, place="Global", drivers_only=True))


def _order_device_names(
    names: set[str],
    catalog: NameCatalog,
    *,
    place: str,
    drivers_only: bool = False,
) -> list[str]:
    ranked: list[tuple[int, int, str]] = []
    for name in names:
        order, device_id = _device_rank(catalog, name, place=place, drivers_only=drivers_only)
        ranked.append((order, device_id, name))
    ranked.sort()
    return [name for _, _, name in ranked]


def _device_rank(
    catalog: NameCatalog,
    name: str,
    *,
    place: str,
    drivers_only: bool,
) -> tuple[int, int]:
    matches: list[tuple[int, int, int]] = []
    name_map = (
        catalog.device_source_name_by_id
        if not drivers_only
        else catalog.device_by_id
    )
    for device_id, device_name in name_map.items():
        if device_name != name:
            continue
        if drivers_only and device_id not in catalog.driver_device_ids:
            continue
        room_id = catalog.device_room_by_id.get(device_id, 0)
        room_name = catalog.room_name(room_id) if room_id else "Global"
        display_order = catalog.device_display_order_by_id.get(device_id, device_id)
        scope = 0 if room_name == place else 1
        matches.append((scope, display_order, device_id))
    if not matches and not drivers_only:
        # Fall back to DisplayName-preferred map (legacy / activity labels).
        for device_id, device_name in catalog.device_by_id.items():
            if device_name != name:
                continue
            room_id = catalog.device_room_by_id.get(device_id, 0)
            room_name = catalog.room_name(room_id) if room_id else "Global"
            display_order = catalog.device_display_order_by_id.get(device_id, device_id)
            scope = 0 if room_name == place else 1
            matches.append((scope, display_order, device_id))
    if not matches:
        return (_FALLBACK, _FALLBACK)
    matches.sort()
    _scope, display_order, device_id = matches[0]
    return (display_order, device_id)
