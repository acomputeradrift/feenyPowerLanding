from __future__ import annotations

from sentinel_lite.records import InventoryRow

_IDENTITY_FIELDS: tuple[str, ...] = (
    "template",
    "source_table",
    "source_key",
    "device",
    "source",
    "page",
    "layer",
    "viewport_layer",
)


def identity_key(row: InventoryRow) -> str:
    """Stable store identity. Device/source/page distinguish shared-layer buttons."""
    return "|".join(getattr(row, field) for field in _IDENTITY_FIELDS)
