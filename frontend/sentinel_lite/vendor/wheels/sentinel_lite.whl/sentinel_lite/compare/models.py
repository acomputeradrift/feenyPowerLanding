from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from sentinel_lite.records import InventoryRow


class ChangeKind(str, Enum):
    ADDED = "added"
    REMOVED = "removed"
    CHANGED = "changed"


@dataclass(frozen=True)
class FieldDelta:
    field: str
    old: str
    new: str


@dataclass(frozen=True)
class DiffChange:
    kind: ChangeKind
    previous: InventoryRow | None
    current: InventoryRow | None
    deltas: tuple[FieldDelta, ...]


@dataclass(frozen=True)
class ChangelogEntry:
    kind: ChangeKind
    template: str
    place: str
    branch: str
    line: str
    deltas: tuple[FieldDelta, ...]
    source: str = ""
    driver: str = ""
    # (structure label, display text) for hover titles on path segments
    segments: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class CompareResult:
    entries: tuple[ChangelogEntry, ...]
    previous_file: str
    current_file: str
    place_order: tuple[str, ...] = ()
    source_order: tuple[tuple[str, tuple[str, ...]], ...] = ()
    driver_order: tuple[str, ...] = ()
    system_name: str = ""
