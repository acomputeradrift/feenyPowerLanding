from __future__ import annotations

from collections.abc import Sequence

from sentinel_lite.compare.models import ChangeKind, DiffChange, FieldDelta
from sentinel_lite.records import InventoryRow

SYSTEM_FIELDS: tuple[str, ...] = ("place", "object", "pane", "item", "details")
PROGRAMMING_FIELDS: tuple[str, ...] = (
    "device",
    "source",
    "page",
    "layer",
    "viewport_layer",
    "type",
    "identity",
    "macro_scope",
    "variable_scope",
    "page_link",
    "details",
)
# Hook bodies carry the activity/source name for path display only — rename lives on the
# identity row. Comparing object here doubles the rename onto every event line.
_HOOK_BODY_PANES = frozenset(
    {
        "Selection Events",
        "Deselection Events",
        "Room Events",
        "Usage Events / Source Power Events",
    }
)


def diff_rows(
    previous: Sequence[InventoryRow],
    current: Sequence[InventoryRow],
) -> tuple[DiffChange, ...]:
    previous_by_id = _index(previous)
    current_by_id = _index(current)
    keys = set(previous_by_id) | set(current_by_id)
    changes: list[DiffChange] = []
    for key in keys:
        old_row = previous_by_id.get(key)
        new_row = current_by_id.get(key)
        if old_row is None and new_row is not None:
            changes.append(
                DiffChange(ChangeKind.ADDED, previous=None, current=new_row, deltas=())
            )
        elif new_row is None and old_row is not None:
            changes.append(
                DiffChange(ChangeKind.REMOVED, previous=old_row, current=None, deltas=())
            )
        elif old_row is not None and new_row is not None:
            deltas = _deltas(old_row, new_row)
            if deltas:
                changes.append(
                    DiffChange(
                        ChangeKind.CHANGED,
                        previous=old_row,
                        current=new_row,
                        deltas=deltas,
                    )
                )
    changes.sort(key=_sort_tuple)
    return tuple(changes)


def _index(rows: Sequence[InventoryRow]) -> dict[str, InventoryRow]:
    indexed: dict[str, InventoryRow] = {}
    for row in rows:
        if not row.identity_key:
            raise ValueError("InventoryRow.identity_key is required before compare")
        indexed[row.identity_key] = row
    return indexed


def _comparable_fields(row: InventoryRow) -> tuple[str, ...]:
    if row.template == "programming":
        return PROGRAMMING_FIELDS
    if str(row.pane or "").strip() in _HOOK_BODY_PANES or str(row.pane or "").startswith(
        "Usage Events"
    ):
        return tuple(field for field in SYSTEM_FIELDS if field != "object")
    return SYSTEM_FIELDS


def _deltas(previous: InventoryRow, current: InventoryRow) -> tuple[FieldDelta, ...]:
    fields = _comparable_fields(current if current.template else previous)
    deltas: list[FieldDelta] = []
    for field in fields:
        old = str(getattr(previous, field) or "")
        new = str(getattr(current, field) or "")
        if old != new:
            deltas.append(FieldDelta(field=field, old=old, new=new))
    return tuple(deltas)


def _sort_tuple(change: DiffChange) -> tuple[str, str]:
    row = change.current or change.previous
    assert row is not None
    return (row.sort_key, row.identity_key)
