from __future__ import annotations

from sentinel_lite.records import InventoryRow

_SOURCE_PANES = ("Usage Events", "Source Properties", "Source Events")


def filter_place(row: InventoryRow) -> str:
    return row.place or "Global"


def filter_branch(row: InventoryRow) -> str:
    """Changelog filter branch under the place. Empty for place identity (add/remove/rename)."""
    if row.template == "programming":
        return "sources"
    section = f" / {row.section} /"
    if "/ Drivers /" in section:
        return "drivers"
    if "/ Activities /" in section:
        return "activities"
    if "/ Controllers /" in section:
        return "controllers"
    if "/ Sources /" in section:
        return "sources"
    if row.pane.startswith("Room Events") or row.section.endswith("Room Events"):
        return "room-events"
    if row.object == "Processor" or "/ Processor /" in section:
        return "processor"
    if any(row.pane.startswith(prefix) for prefix in _SOURCE_PANES):
        return "sources"
    if row.pane == "Room List":
        return "controllers"
    if row.pane.startswith("Properties"):
        return "controllers"
    if row.pane == "Macro List":
        return _list_branch(row, default="macro-list")
    if row.pane == "Variable List":
        return _list_branch(row, default="variable-list")
    if row.object:
        return "controllers"
    return ""


def filter_source(row: InventoryRow) -> str:
    """Named source under the Sources filter branch. Empty when not a Sources line."""
    if filter_branch(row) != "sources":
        return ""
    if row.template == "programming":
        return (row.source or "").strip()
    return (row.object or row.source or "").strip()


def filter_driver(row: InventoryRow) -> str:
    """Named driver under the Drivers filter branch. Empty when not a Drivers line."""
    if filter_branch(row) != "drivers":
        return ""
    return (row.object or "").strip()


def _list_branch(row: InventoryRow, *, default: str) -> str:
    if not row.object:
        return default
    if ".50." in row.sort_key:
        return "sources"
    if ".40." in row.sort_key or row.sort_key.startswith("01.04."):
        return "controllers"
    return "sources"
