from __future__ import annotations

from collections.abc import Sequence

from sentinel_lite.compare.branches import filter_branch, filter_driver, filter_place, filter_source
from sentinel_lite.compare.engine import diff_rows
from sentinel_lite.compare.filter_order import (
    driver_order,
    merge_catalogs,
    place_order,
    source_order,
)
from sentinel_lite.compare.format import format_line, path_segments, split_change_deltas
from sentinel_lite.compare.models import ChangelogEntry, CompareResult
from sentinel_lite.records import InventoryRow
from sentinel_lite.resolve.catalog import NameCatalog


def compare_inventories(
    previous: Sequence[InventoryRow],
    current: Sequence[InventoryRow],
    *,
    previous_file: str,
    current_file: str,
    previous_catalog: NameCatalog | None = None,
    current_catalog: NameCatalog | None = None,
) -> CompareResult:
    entries: list[ChangelogEntry] = []
    for change in diff_rows(previous, current):
        row = change.current or change.previous
        assert row is not None
        for deltas in split_change_deltas(change.kind, row, change.deltas):
            segments = path_segments(change.kind, row, deltas)
            entries.append(
                ChangelogEntry(
                    kind=change.kind,
                    template=row.template,
                    place=filter_place(row),
                    branch=filter_branch(row),
                    line=format_line(change.kind, row, deltas),
                    deltas=deltas,
                    source=filter_source(row),
                    driver=filter_driver(row),
                    segments=segments,
                )
            )
    catalog = merge_catalogs(
        *(catalog for catalog in (previous_catalog, current_catalog) if catalog is not None)
    )
    entry_tuple = tuple(entries)
    # Prefer current file's System Name (RTiQConfig.Name); fall back to previous.
    system_name = ""
    if current_catalog and current_catalog.system_name:
        system_name = current_catalog.system_name
    elif previous_catalog and previous_catalog.system_name:
        system_name = previous_catalog.system_name
    elif catalog.system_name:
        system_name = catalog.system_name
    return CompareResult(
        entries=entry_tuple,
        previous_file=previous_file,
        current_file=current_file,
        place_order=place_order(entry_tuple, catalog) if catalog.room_by_id else (),
        source_order=source_order(entry_tuple, catalog) if catalog.device_by_id else (),
        driver_order=driver_order(entry_tuple, catalog) if catalog.device_by_id else (),
        system_name=system_name,
    )
